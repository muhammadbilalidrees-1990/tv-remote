#!/usr/bin/env python3
"""Patch the Info.plist that `flutter create` generates for iOS.

Without this the app looks fine and silently finds nothing:

1. iOS 14 and later block every connection to a device on the local network
   until the user grants Local Network permission — and iOS refuses to even
   show that prompt unless NSLocalNetworkUsageDescription explains why. No
   string, no prompt, no TV.
2. The app label would be "tv_remote".

Note on SSDP: multicast on iOS needs a special Apple entitlement that has to
be applied for, and a sideloaded build can't carry it. So Samsung's fast SSDP
discovery won't work on iPhone — the subnet scan in discovery.dart is what
finds TVs there, which is why it always runs.

Run from the project root, after `flutter create`.
"""

import plistlib
import sys
from pathlib import Path

PLIST = Path("ios/Runner/Info.plist")

APP_NAME = "TV Remote"

LOCAL_NETWORK_REASON = (
    "TV Remote connects to your TV over Wi-Fi. Without access to this network "
    "it cannot find or control the TV."
)

# Only needed if we ever browse via Bonjour, but harmless to declare and it
# saves a rebuild later.
BONJOUR_SERVICES = [
    "_androidtvremote2._tcp",
    "_googlecast._tcp",
]


def fail(message: str) -> None:
    print(f"patch_ios: ERROR: {message}", file=sys.stderr)
    sys.exit(1)


def main() -> None:
    if not PLIST.exists():
        fail(f"{PLIST} not found. Run `flutter create --platforms=ios .` first.")

    with PLIST.open("rb") as handle:
        plist = plistlib.load(handle)

    before = dict(plist)

    plist["NSLocalNetworkUsageDescription"] = LOCAL_NETWORK_REASON
    plist["NSBonjourServices"] = BONJOUR_SERVICES
    plist["CFBundleDisplayName"] = APP_NAME
    plist["CFBundleName"] = APP_NAME

    # Portrait only, matching the Android build and main.dart.
    plist["UISupportedInterfaceOrientations"] = ["UIInterfaceOrientationPortrait"]

    if plist == before:
        print("patch_ios: nothing to change, Info.plist already patched")
        return

    with PLIST.open("wb") as handle:
        plistlib.dump(plist, handle)

    print("patch_ios: Info.plist patched")
    print("  + NSLocalNetworkUsageDescription")
    print(f"  + NSBonjourServices ({len(BONJOUR_SERVICES)} entries)")
    print(f'  + CFBundleDisplayName = "{APP_NAME}"')
    print("  + portrait orientation only")


if __name__ == "__main__":
    main()
