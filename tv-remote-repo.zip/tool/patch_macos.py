#!/usr/bin/env python3
"""Patch what `flutter create --platforms=macos` generates.

A Mac app is sandboxed by default and gets NO network access at all. The app
would launch, look perfectly healthy, find no TVs and report nothing useful —
the same silent failure the Android manifest had.

Three things are needed:

1. `com.apple.security.network.client` in BOTH entitlements files. Flutter
   puts it in DebugProfile.entitlements only, so a release build — which is
   what we ship — comes out with no network at all.
2. `com.apple.security.network.server`, because discovery listens for SSDP
   replies rather than only making outbound requests.
3. `NSLocalNetworkUsageDescription`. macOS Sequoia asks permission before an
   app may talk to devices on the local network, and like iOS it refuses to
   show the prompt without a reason string.

Run from the project root, after `flutter create`.
"""

import plistlib
import sys
from pathlib import Path

PLIST = Path("macos/Runner/Info.plist")
ENTITLEMENTS = [
    Path("macos/Runner/Release.entitlements"),
    Path("macos/Runner/DebugProfile.entitlements"),
]

APP_NAME = "TV Remote"

LOCAL_NETWORK_REASON = (
    "TV Remote connects to your TV over Wi-Fi. Without access to this network "
    "it cannot find or control the TV."
)

NEEDED = {
    "com.apple.security.network.client": True,
    "com.apple.security.network.server": True,
}


def fail(message: str) -> None:
    print(f"patch_macos: ERROR: {message}", file=sys.stderr)
    sys.exit(1)


def patch_entitlements(path: Path) -> None:
    if not path.exists():
        print(f"patch_macos: {path} not found, skipping")
        return

    with path.open("rb") as handle:
        plist = plistlib.load(handle)

    added = [key for key, value in NEEDED.items() if plist.get(key) != value]
    if not added:
        print(f"patch_macos: {path.name} already allows networking")
        return

    plist.update(NEEDED)
    with path.open("wb") as handle:
        plistlib.dump(plist, handle)

    print(f"patch_macos: {path.name} patched")
    for key in added:
        print(f"  + {key}")


def patch_plist() -> None:
    if not PLIST.exists():
        fail(f"{PLIST} not found. Run `flutter create --platforms=macos .` first.")

    with PLIST.open("rb") as handle:
        plist = plistlib.load(handle)

    before = dict(plist)
    plist["NSLocalNetworkUsageDescription"] = LOCAL_NETWORK_REASON
    plist["NSBonjourServices"] = ["_androidtvremote2._tcp", "_googlecast._tcp"]
    plist["CFBundleName"] = APP_NAME
    plist["CFBundleDisplayName"] = APP_NAME

    if plist == before:
        print("patch_macos: Info.plist already patched")
        return

    with PLIST.open("wb") as handle:
        plistlib.dump(plist, handle)

    print("patch_macos: Info.plist patched")
    print("  + NSLocalNetworkUsageDescription")
    print(f'  + CFBundleDisplayName = "{APP_NAME}"')


def main() -> None:
    patch_plist()
    for path in ENTITLEMENTS:
        patch_entitlements(path)


if __name__ == "__main__":
    main()
