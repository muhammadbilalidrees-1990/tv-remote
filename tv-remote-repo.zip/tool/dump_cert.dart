// Prints the client certificate the app generates, so its structure can be
// inspected without a phone.
//
//     dart run tool/dump_cert.dart
//
// The TV rejects the app's handshake with alert 47 (illegal_parameter) while
// accepting a .NET-generated certificate, so the certificate is the suspect.
// This dumps the PEM plus a decoded view of the bits that matter: the X.509
// version, the extensions, and the signature algorithm.

import 'dart:convert';
import 'dart:typed_data';

import 'package:tv_remote/services/atv/atv_crypto.dart';

void main() async {
  final identity = await AtvCrypto.generateIdentity();

  print('===== CERTIFICATE PEM =====');
  print(identity.certificatePem.trim());
  print('===== END CERTIFICATE PEM =====');
  print('');

  final der = base64Decode(identity.certificatePem
      .replaceAll(RegExp(r'-----(BEGIN|END) CERTIFICATE-----'), '')
      .replaceAll(RegExp(r'\s'), ''));

  print('DER length: ${der.length} bytes');
  print('');
  print('===== STRUCTURE =====');
  _describe(der);

  print('');
  print('===== RSA NUMBERS (what the pairing hash uses) =====');
  final numbers = AtvCrypto.numbersFromPem(identity.certificatePem);
  print('modulus:  ${numbers.modulus.length} bytes, first byte '
      '0x${numbers.modulus.first.toRadixString(16).padLeft(2, '0')}');
  print('exponent: ${_hex(numbers.exponent)}');
}

/// Walks the top of the certificate and reports the parts that decide whether
/// a TLS stack will accept it.
void _describe(Uint8List der) {
  try {
    final certificate = _children(_tlv(der, 0).content);
    final tbs = _children(certificate[0].content);

    final hasVersionTag = tbs.isNotEmpty && tbs[0].tag == 0xA0;
    print('version field present : $hasVersionTag');
    if (hasVersionTag) {
      final versionBytes = _children(tbs[0].content);
      final v = versionBytes.isNotEmpty && versionBytes[0].content.isNotEmpty
          ? versionBytes[0].content.last
          : -1;
      print('version value         : $v  (2 means v3, which extensions require)');
    } else {
      print('version value         : absent, so v1 by default');
    }

    print('tbsCertificate fields : ${tbs.length}');
    for (var i = 0; i < tbs.length; i++) {
      print('  [$i] tag 0x${tbs[i].tag.toRadixString(16).padLeft(2, '0')}  '
          'length ${tbs[i].content.length}');
    }

    // Extensions live in an explicit [3] tag at the end of tbsCertificate.
    final extensions = tbs.where((t) => t.tag == 0xA3).toList();
    print('extensions block      : ${extensions.isEmpty ? "none" : "present"}');

    if (extensions.isNotEmpty && !hasVersionTag) {
      print('');
      print('*** INVALID: extensions are present but the certificate is v1.');
      print('*** Extensions are only legal in v3. This is very likely the');
      print('*** reason the TV rejects the handshake.');
    }

    print('signature algorithm   : ${_hex(certificate[1].content)}');
  } catch (e) {
    print('could not decode: $e');
  }
}

String _hex(Uint8List b) =>
    b.map((x) => x.toRadixString(16).padLeft(2, '0')).join(' ');

class _Tlv {
  final int tag;
  final Uint8List content;
  final int end;
  const _Tlv(this.tag, this.content, this.end);
}

_Tlv _tlv(Uint8List data, int offset) {
  final tag = data[offset];
  var i = offset + 1;
  var length = data[i];
  i++;
  if (length & 0x80 != 0) {
    final count = length & 0x7F;
    length = 0;
    for (var k = 0; k < count; k++) {
      length = (length << 8) | data[i];
      i++;
    }
  }
  return _Tlv(tag, Uint8List.sublistView(data, i, i + length), i + length);
}

List<_Tlv> _children(Uint8List content) {
  final out = <_Tlv>[];
  var offset = 0;
  while (offset < content.length) {
    final t = _tlv(content, offset);
    out.add(t);
    offset = t.end;
  }
  return out;
}
