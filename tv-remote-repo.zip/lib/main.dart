import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens/remote_screen.dart';
import 'services/samsung_remote.dart';
import 'widgets/palette.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const TvRemoteApp());
}

class TvRemoteApp extends StatefulWidget {
  const TvRemoteApp({super.key});

  @override
  State<TvRemoteApp> createState() => _TvRemoteAppState();
}

class _TvRemoteAppState extends State<TvRemoteApp> {
  final _remote = SamsungRemote();

  @override
  void dispose() {
    _remote.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TV Remote',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Palette.body,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Palette.signal,
          brightness: Brightness.dark,
          surface: Palette.body,
        ),
        appBarTheme: const AppBarTheme(
          foregroundColor: Palette.text,
          elevation: 0,
          scrolledUnderElevation: 0,
        ),
      ),
      home: RemoteScreen(remote: _remote),
    );
  }
}
