import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/samsung_remote.dart';
import 'palette.dart';

/// Recent entries for this session only — never saved to disk,
/// because people type passwords and emails here.
final List<String> _recent = [];

Future<void> showTvKeyboard(BuildContext context, SamsungRemote remote) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Palette.panel,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => _KeyboardSheet(remote: remote),
  );
}

class _KeyboardSheet extends StatefulWidget {
  final SamsungRemote remote;
  const _KeyboardSheet({required this.remote});

  @override
  State<_KeyboardSheet> createState() => _KeyboardSheetState();
}

class _KeyboardSheetState extends State<_KeyboardSheet> {
  final _controller = TextEditingController();
  bool _hidden = false; // for passwords
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _send() {
    final text = _controller.text;
    if (text.isEmpty) {
      setState(() => _error = 'Type something first.');
      return;
    }
    if (!widget.remote.sendText(text)) {
      setState(() => _error = 'Not connected to a TV.');
      return;
    }
    widget.remote.endInput();

    if (!_hidden) {
      _recent
        ..remove(text)
        ..insert(0, text);
      if (_recent.length > 5) _recent.removeLast();
    }
    HapticFeedback.lightImpact();
    Navigator.of(context).pop();
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final t = data?.text;
    if (t == null || t.isEmpty || !mounted) return;
    _setText(t);
  }

  void _setText(String t) {
    _controller.value = TextEditingValue(
      text: t,
      selection: TextSelection.collapsed(offset: t.length),
    );
    setState(() => _error = null);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      // Keep the sheet above the phone keyboard.
      padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text('Type on TV',
                        style: TextStyle(
                            color: Palette.text,
                            fontSize: 17,
                            fontWeight: FontWeight.w600)),
                  ),
                  IconButton(
                    tooltip: _hidden ? 'Show text' : 'Hide text',
                    onPressed: () => setState(() => _hidden = !_hidden),
                    icon: Icon(_hidden
                        ? Icons.visibility_rounded
                        : Icons.visibility_off_rounded),
                  ),
                  IconButton(
                    tooltip: 'Paste',
                    onPressed: _paste,
                    icon: const Icon(Icons.content_paste_rounded),
                  ),
                ],
              ),
              const Text(
                'Select a search box or text field on the TV first.',
                style: TextStyle(color: Palette.muted, fontSize: 13),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _controller,
                autofocus: true,
                obscureText: _hidden,
                autocorrect: !_hidden,
                enableSuggestions: !_hidden,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                onChanged: (_) {
                  if (_error != null) setState(() => _error = null);
                },
                style: const TextStyle(color: Palette.text, fontSize: 17),
                decoration: InputDecoration(
                  hintText: 'Search, email, Wi-Fi password…',
                  errorText: _error,
                  filled: true,
                  fillColor: Palette.key,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                  suffixIcon: IconButton(
                    tooltip: 'Clear',
                    onPressed: () => _setText(''),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ),
              ),
              if (_recent.isNotEmpty) ...[
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final r in _recent)
                      ActionChip(
                        label: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 200),
                          child: Text(r,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                        ),
                        backgroundColor: Palette.key,
                        side: BorderSide.none,
                        onPressed: () => _setText(r),
                      ),
                  ],
                ),
              ],
              const SizedBox(height: 16),
              Row(
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Cancel'),
                  ),
                  const Spacer(),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: Palette.signal,
                      minimumSize: const Size(0, 48),
                    ),
                    onPressed: _send,
                    icon: const Icon(Icons.send_rounded, size: 18),
                    label: const Text('Send to TV'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
