import 'package:flutter/material.dart';

/// Graphite body with one signal-blue accent (the OK key) —
/// modelled on a physical remote, not a generic app screen.
class Palette {
  static const body = Color(0xFF1E232A); // remote casing
  static const panel = Color(0xFF262C34); // recessed areas
  static const key = Color(0xFF323943); // raised keys
  static const keyPressed = Color(0xFF444D59);
  static const text = Color(0xFFE6EAEF);
  static const muted = Color(0xFF8B95A3);
  static const signal = Color(0xFF4F8CFF); // OK key, connected state
  static const power = Color(0xFFE5534B);
  static const amber = Color(0xFFE8A93A); // waiting for approval
}
