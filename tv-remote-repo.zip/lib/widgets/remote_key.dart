import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'palette.dart';

/// A physical-feeling key: haptic tick, pressed shade, optional hold-to-repeat.
class RemoteKey extends StatefulWidget {
  final Widget child;
  final VoidCallback onPressed;
  final String label; // for screen readers
  final bool repeat;
  final double width;
  final double height;
  final Color color;
  final BorderRadius borderRadius;

  const RemoteKey({
    super.key,
    required this.child,
    required this.onPressed,
    required this.label,
    this.repeat = false,
    this.width = 64,
    this.height = 52,
    this.color = Palette.key,
    this.borderRadius = const BorderRadius.all(Radius.circular(16)),
  });

  @override
  State<RemoteKey> createState() => _RemoteKeyState();
}

class _RemoteKeyState extends State<RemoteKey> {
  bool _pressed = false;
  Timer? _timer;

  void _fire() {
    HapticFeedback.selectionClick();
    widget.onPressed();
  }

  void _startRepeat() {
    setState(() => _pressed = true);
    _fire();
    _timer = Timer.periodic(const Duration(milliseconds: 140), (_) => _fire());
  }

  void _stop() {
    _timer?.cancel();
    _timer = null;
    if (mounted) setState(() => _pressed = false);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final neutral =
        widget.color == Palette.key || widget.color == Colors.transparent;
    final Color bg = neutral
        ? (_pressed ? Palette.keyPressed : widget.color)
        : widget.color.withAlpha(_pressed ? 190 : 255);

    return Semantics(
      button: true,
      label: widget.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) => _stop(),
        onTapCancel: () {
          if (_timer == null) _stop();
        },
        onTap: _fire,
        onLongPressStart: widget.repeat ? (_) => _startRepeat() : null,
        onLongPressEnd: widget.repeat ? (_) => _stop() : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 70),
          width: widget.width,
          height: widget.height,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: widget.borderRadius,
          ),
          transform: Matrix4.translationValues(0, _pressed ? 1.5 : 0, 0),
          child: IconTheme(
            data: const IconThemeData(color: Palette.text, size: 24),
            child: DefaultTextStyle(
              style: const TextStyle(
                color: Palette.text,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
              child: widget.child,
            ),
          ),
        ),
      ),
    );
  }
}

/// Circular direction pad with the OK key in the centre.
class DPad extends StatelessWidget {
  final void Function(String key) onKey;
  final double size;

  const DPad({super.key, required this.onKey, this.size = 250});

  @override
  Widget build(BuildContext context) {
    final arm = size * 0.30;
    final ok = size * 0.36;

    Widget arrow(IconData icon, String key, String label) => RemoteKey(
          label: label,
          repeat: true,
          width: arm,
          height: arm,
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(arm / 2),
          onPressed: () => onKey(key),
          child: Icon(icon, size: 34, color: Palette.muted),
        );

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            decoration: const BoxDecoration(
              color: Palette.key,
              shape: BoxShape.circle,
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: arrow(Icons.keyboard_arrow_up_rounded, 'KEY_UP', 'Up'),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: arrow(Icons.keyboard_arrow_down_rounded, 'KEY_DOWN', 'Down'),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: arrow(Icons.keyboard_arrow_left_rounded, 'KEY_LEFT', 'Left'),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: arrow(Icons.keyboard_arrow_right_rounded, 'KEY_RIGHT', 'Right'),
          ),
          RemoteKey(
            label: 'OK',
            width: ok,
            height: ok,
            color: Palette.signal,
            borderRadius: BorderRadius.circular(ok / 2),
            onPressed: () => onKey('KEY_ENTER'),
            child: const Text('OK',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

/// Tall pill for volume / channel: + on top, - at the bottom.
class Rocker extends StatelessWidget {
  final String label;
  final String upKey;
  final String downKey;
  final void Function(String key) onKey;

  const Rocker({
    super.key,
    required this.label,
    required this.upKey,
    required this.downKey,
    required this.onKey,
  });

  @override
  Widget build(BuildContext context) {
    const w = 64.0;
    return Container(
      width: w,
      decoration: BoxDecoration(
        color: Palette.key,
        borderRadius: BorderRadius.circular(w / 2),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          RemoteKey(
            label: '$label up',
            repeat: true,
            width: w,
            height: 58,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(w / 2)),
            onPressed: () => onKey(upKey),
            child: const Icon(Icons.add_rounded),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Text(label,
                style: const TextStyle(color: Palette.muted, fontSize: 13)),
          ),
          RemoteKey(
            label: '$label down',
            repeat: true,
            width: w,
            height: 58,
            borderRadius:
                const BorderRadius.vertical(bottom: Radius.circular(w / 2)),
            onPressed: () => onKey(downKey),
            child: const Icon(Icons.remove_rounded),
          ),
        ],
      ),
    );
  }
}
