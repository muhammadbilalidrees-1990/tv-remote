/// Which protocol a TV speaks. They have nothing in common: Samsung uses a
/// WebSocket with a pairing token, Google TV uses TLS with a client
/// certificate and binary protobuf.
enum TvBrand {
  samsung,
  androidTv;

  static TvBrand fromName(String? name) =>
      name == 'androidTv' ? TvBrand.androidTv : TvBrand.samsung;

  String get label => this == TvBrand.androidTv ? 'Google TV' : 'Samsung';
}

/// A TV found on the local network.
class TvDevice {
  final String ip;
  final String name;
  final String model;
  final String? mac; // needed for Wake-on-LAN (turning the TV on)
  final bool tokenAuth; // Samsung only: secure port with a pairing token
  final TvBrand brand;

  const TvDevice({
    required this.ip,
    required this.name,
    this.model = '',
    this.mac,
    this.tokenAuth = true,
    this.brand = TvBrand.samsung,
  });

  /// Builds a Samsung device from its info endpoint: GET http://<ip>:8001/api/v2/
  factory TvDevice.fromInfo(String ip, Map<String, dynamic> info) {
    final d = (info['device'] is Map)
        ? (info['device'] as Map).cast<String, dynamic>()
        : <String, dynamic>{};
    final mac = d['wifiMac']?.toString();
    return TvDevice(
      ip: ip,
      name: (d['name'] ?? info['name'] ?? 'Samsung TV').toString(),
      model: (d['modelName'] ?? '').toString(),
      mac: (mac == null || mac.isEmpty) ? null : mac,
      tokenAuth: d['TokenAuthSupport']?.toString() == 'true',
      brand: TvBrand.samsung,
    );
  }

  /// A Google TV / Android TV. Its remote ports give away nothing but the
  /// address, so the name stays generic until the user renames it.
  factory TvDevice.androidTv(String ip, {String? name, String? mac}) => TvDevice(
        ip: ip,
        name: (name == null || name.isEmpty) ? 'Google TV' : name,
        mac: (mac == null || mac.isEmpty) ? null : mac,
        brand: TvBrand.androidTv,
      );

  TvDevice copyWith({String? name}) => TvDevice(
        ip: ip,
        name: name ?? this.name,
        model: model,
        mac: mac,
        tokenAuth: tokenAuth,
        brand: brand,
      );

  Map<String, dynamic> toJson() => {
        'ip': ip,
        'name': name,
        'model': model,
        'mac': mac,
        'tokenAuth': tokenAuth,
        'brand': brand.name,
      };

  factory TvDevice.fromJson(Map<String, dynamic> j) => TvDevice(
        ip: j['ip'] as String,
        name: (j['name'] ?? 'Samsung TV') as String,
        model: (j['model'] ?? '') as String,
        mac: j['mac'] as String?,
        tokenAuth: (j['tokenAuth'] ?? true) as bool,
        // Devices saved before Google TV support have no brand recorded.
        brand: TvBrand.fromName(j['brand'] as String?),
      );
}
