/// A Samsung TV found on the local network.
class TvDevice {
  final String ip;
  final String name;
  final String model;
  final String? mac; // needed for Wake-on-LAN (turning the TV on)
  final bool tokenAuth;

  const TvDevice({
    required this.ip,
    required this.name,
    this.model = '',
    this.mac,
    this.tokenAuth = true,
  });

  /// Builds a device from the TV's info endpoint: GET http://<ip>:8001/api/v2/
  factory TvDevice.fromInfo(String ip, Map<String, dynamic> info) {
    final d = (info['device'] is Map)
        ? (info['device'] as Map).cast<String, dynamic>()
        : <String, dynamic>{};
    final mac = d['wifiMac']?.toString();
    return TvDevice(
      ip: ip,
      name: (d['name'] ?? info['name'] ?? 'Samsung TV').toString(),
      model: (d['modelName'] ?? '').toString(),
      mac: (mac == null || mac.isEmpty) ? null : mac,
      tokenAuth: d['TokenAuthSupport']?.toString() == 'true',
    );
  }

  Map<String, dynamic> toJson() => {
        'ip': ip,
        'name': name,
        'model': model,
        'mac': mac,
        'tokenAuth': tokenAuth,
      };

  factory TvDevice.fromJson(Map<String, dynamic> j) => TvDevice(
        ip: j['ip'] as String,
        name: (j['name'] ?? 'Samsung TV') as String,
        model: (j['model'] ?? '') as String,
        mac: j['mac'] as String?,
        tokenAuth: (j['tokenAuth'] ?? true) as bool,
      );
}
