/// Which protocol a TV speaks. They have nothing in common:
///
///   samsung        2016+ Tizen. WebSocket, pairing token, full key set.
///   samsungLegacy  2015 and older. No key injection exists on these sets at
///                  all — only UPnP for volume, mute and input switching.
///   androidTv      TLS with a client certificate and binary protobuf.
enum TvBrand {
  samsung,
  samsungLegacy,
  androidTv;

  static TvBrand fromName(String? name) {
    switch (name) {
      case 'androidTv':
        return TvBrand.androidTv;
      case 'samsungLegacy':
        return TvBrand.samsungLegacy;
      default:
        return TvBrand.samsung;
    }
  }

  String get label {
    switch (this) {
      case TvBrand.androidTv:
        return 'Google TV';
      case TvBrand.samsungLegacy:
        return 'Samsung (pre-2016)';
      case TvBrand.samsung:
        return 'Samsung';
    }
  }

  bool get isSamsung => this == TvBrand.samsung || this == TvBrand.samsungLegacy;
}

/// A TV found on the local network.
class TvDevice {
  final String ip;
  final String name;
  final String model;
  final String? mac; // needed for Wake-on-LAN (turning the TV on)
  final bool tokenAuth; // Samsung only: secure port with a pairing token
  final TvBrand brand;

  const TvDevice({
    required this.ip,
    required this.name,
    this.model = '',
    this.mac,
    this.tokenAuth = true,
    this.brand = TvBrand.samsung,
  });

  /// Builds a Samsung device from its info endpoint: GET http://<ip>:8001/api/v2/
  factory TvDevice.fromInfo(String ip, Map<String, dynamic> info) {
    final d = (info['device'] is Map)
        ? (info['device'] as Map).cast<String, dynamic>()
        : <String, dynamic>{};
    final mac = d['wifiMac']?.toString();
    return TvDevice(
      ip: ip,
      name: (d['name'] ?? info['name'] ?? 'Samsung TV').toString(),
      model: (d['modelName'] ?? '').toString(),
      mac: (mac == null || mac.isEmpty) ? null : mac,
      tokenAuth: d['TokenAuthSupport']?.toString() == 'true',
      brand: _isPreTizen(d) ? TvBrand.samsungLegacy : TvBrand.samsung,
    );
  }

  /// True for a TV old enough to have no remote-control API.
  ///
  /// Every 2016-or-newer set advertises TokenAuthSupport, whether it wants a
  /// token or not. A set that never mentions it is pre-Tizen, and a UA55H6400
  /// proved the point: it accepts the WebSocket, greets you politely, then
  /// answers every key with "unrecognized method value : ms.remote.control".
  ///
  /// The model name settles it. Samsung encodes the year as a letter after
  /// the screen size — UA55*H*6400 is 2014. D/E/F/H are 2011-14; J is 2015,
  /// the first Tizen year. (Samsung restarted the letters at A in 2021, but
  /// those all advertise TokenAuthSupport, so they never reach this check.)
  static bool _isPreTizen(Map<String, dynamic> device) {
    if (device.containsKey('TokenAuthSupport')) return false;

    final model = (device['modelName'] ?? '').toString().toUpperCase();
    final match = RegExp(r'^[A-Z]{2}\d{2}([A-Z])').firstMatch(model);
    if (match != null) {
      // Anything before J (2015) has no remote API.
      return match.group(1)!.compareTo('J') < 0;
    }

    // Unreadable model and no token support advertised: the modern path has
    // nothing to offer a TV that has never heard of tokens.
    return true;
  }

  /// A Google TV / Android TV. Its remote ports give away nothing but the
  /// address, so the name stays generic until the user renames it.
  factory TvDevice.androidTv(String ip, {String? name, String? mac}) => TvDevice(
        ip: ip,
        name: (name == null || name.isEmpty) ? 'Google TV' : name,
        mac: (mac == null || mac.isEmpty) ? null : mac,
        brand: TvBrand.androidTv,
      );

  TvDevice copyWith({String? name, String? mac}) => TvDevice(
        ip: ip,
        name: name ?? this.name,
        model: model,
        mac: mac ?? this.mac,
        tokenAuth: tokenAuth,
        brand: brand,
      );

  Map<String, dynamic> toJson() => {
        'ip': ip,
        'name': name,
        'model': model,
        'mac': mac,
        'tokenAuth': tokenAuth,
        'brand': brand.name,
      };

  factory TvDevice.fromJson(Map<String, dynamic> j) => TvDevice(
        ip: j['ip'] as String,
        name: (j['name'] ?? 'Samsung TV') as String,
        model: (j['model'] ?? '') as String,
        mac: j['mac'] as String?,
        tokenAuth: (j['tokenAuth'] ?? true) as bool,
        // Devices saved before Google TV support have no brand recorded.
        brand: TvBrand.fromName(j['brand'] as String?),
      );
}
