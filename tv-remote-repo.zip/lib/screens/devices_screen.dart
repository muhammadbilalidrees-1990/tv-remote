import 'package:flutter/material.dart';

import '../models/tv_device.dart';
import '../services/discovery.dart';
import '../services/samsung_remote.dart';
import '../widgets/palette.dart';

class DevicesScreen extends StatefulWidget {
  final SamsungRemote remote;
  const DevicesScreen({super.key, required this.remote});

  @override
  State<DevicesScreen> createState() => _DevicesScreenState();
}

class _DevicesScreenState extends State<DevicesScreen> {
  final _ipController = TextEditingController();
  List<TvDevice> _devices = [];
  bool _scanning = false;
  bool _scannedOnce = false;
  String? _manualError;

  @override
  void initState() {
    super.initState();
    _scan();
  }

  @override
  void dispose() {
    _ipController.dispose();
    super.dispose();
  }

  Future<void> _scan() async {
    setState(() => _scanning = true);
    final found = await TvDiscovery.discover();
    if (!mounted) return;
    setState(() {
      _devices = found;
      _scanning = false;
      _scannedOnce = true;
    });
  }

  Future<void> _addManual() async {
    final ip = _ipController.text.trim();
    final valid = RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(ip);
    if (!valid) {
      setState(() => _manualError = 'Enter an IP like 192.168.1.20');
      return;
    }
    setState(() => _manualError = null);
    final tv = await TvDiscovery.probe(ip);
    if (!mounted) return;
    if (tv == null) {
      setState(() => _manualError = 'No Samsung TV answered at $ip');
      return;
    }
    _pick(tv);
  }

  void _pick(TvDevice tv) {
    widget.remote.connect(tv); // remote screen shows progress
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Palette.body,
      appBar: AppBar(
        backgroundColor: Palette.body,
        title: const Text('Choose your TV'),
        actions: [
          IconButton(
            tooltip: 'Scan again',
            onPressed: _scanning ? null : _scan,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (_scanning)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Column(
                children: [
                  CircularProgressIndicator(color: Palette.signal),
                  SizedBox(height: 16),
                  Text('Looking for TVs on your Wi-Fi…',
                      style: TextStyle(color: Palette.muted)),
                ],
              ),
            ),
          if (!_scanning && _scannedOnce && _devices.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Text(
                'No TV found. Make sure the TV is on and on the same Wi-Fi as '
                'this phone, then scan again — or enter its IP below '
                '(TV: Settings > General > Network > Network Status).',
                style: TextStyle(color: Palette.muted, height: 1.4),
              ),
            ),
          for (final tv in _devices)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Material(
                color: Palette.panel,
                borderRadius: BorderRadius.circular(14),
                child: ListTile(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  leading: const Icon(Icons.tv_rounded, color: Palette.text),
                  title: Text(tv.name,
                      style: const TextStyle(color: Palette.text)),
                  subtitle: Text(
                    tv.model.isEmpty ? tv.ip : '${tv.model}, ${tv.ip}',
                    style: const TextStyle(color: Palette.muted),
                  ),
                  onTap: () => _pick(tv),
                ),
              ),
            ),
          const SizedBox(height: 28),
          const Text('Add by IP address',
              style: TextStyle(
                  color: Palette.text,
                  fontSize: 16,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _ipController,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  style: const TextStyle(color: Palette.text),
                  decoration: InputDecoration(
                    hintText: '192.168.1.20',
                    errorText: _manualError,
                    filled: true,
                    fillColor: Palette.panel,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  onSubmitted: (_) => _addManual(),
                ),
              ),
              const SizedBox(width: 10),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: Palette.signal,
                  minimumSize: const Size(0, 52),
                ),
                onPressed: _addManual,
                child: const Text('Connect'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
