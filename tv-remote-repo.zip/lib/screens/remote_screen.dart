import 'dart:async';

import 'package:flutter/material.dart';

import '../services/samsung_remote.dart';
import '../services/samsung_upnp.dart';
import '../widgets/keyboard_sheet.dart';
import '../widgets/palette.dart';
import '../widgets/remote_key.dart';
import 'devices_screen.dart';

/// The width the remote is laid out at. FittedBox scales the whole thing to
/// the real screen, so this is a design unit rather than a pixel count.
const double _designWidth = 360;

/// Tizen app IDs. These vary by region and TV year — verify on your TV.
const _apps = <(String, String)>[
  ('Netflix', '3201907018807'),
  ('YouTube', '111299001912'),
  ('Prime Video', '3201512006785'),
  ('Disney+', '3201901017640'),
  ('Spotify', '3201606009684'),
];

class RemoteScreen extends StatefulWidget {
  final SamsungRemote remote;
  const RemoteScreen({super.key, required this.remote});

  @override
  State<RemoteScreen> createState() => _RemoteScreenState();
}

class _RemoteScreenState extends State<RemoteScreen>
    with WidgetsBindingObserver {
  SamsungRemote get remote => widget.remote;
  DateTime _lastNotice = DateTime.fromMillisecondsSinceEpoch(0);
  StreamSubscription<bool>? _imeSub;
  bool _keyboardOpen = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Pop the keyboard open when a text field is focused on the TV.
    _imeSub = remote.imeActive.listen(_onIme);
    // Google TV shows a code on screen during pairing; this is how the
    // remote asks the user for it.
    remote.onPairingCodeRequested = _askPairingCode;
    _restore();
  }

  @override
  void dispose() {
    _imeSub?.cancel();
    remote.onPairingCodeRequested = null;
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// Asks for the six characters a Google TV puts on screen while pairing.
  /// Returns null if the user backs out.
  Future<String?> _askPairingCode() async {
    if (!mounted) return null;
    final controller = TextEditingController();

    final code = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: Palette.panel,
        title: const Text('Code on the TV', style: TextStyle(color: Palette.text)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Your TV is showing six characters. Type them here.',
              style: TextStyle(color: Palette.muted, fontSize: 14),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: controller,
              autofocus: true,
              maxLength: 6,
              textCapitalization: TextCapitalization.characters,
              style: const TextStyle(
                color: Palette.text,
                fontSize: 24,
                letterSpacing: 8,
              ),
              decoration: const InputDecoration(
                counterText: '',
                hintText: 'A1B2C3',
                hintStyle: TextStyle(color: Palette.muted, letterSpacing: 8),
              ),
              onSubmitted: (v) => Navigator.pop(context, v),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Palette.muted)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Pair', style: TextStyle(color: Palette.signal)),
          ),
        ],
      ),
    );

    controller.dispose();
    return code;
  }

  Future<void> _openKeyboard() async {
    if (_keyboardOpen) return;
    if (!remote.isConnected) {
      _notConnected();
      return;
    }
    _keyboardOpen = true;
    await showTvKeyboard(context, remote);
    _keyboardOpen = false;
  }

  void _onIme(bool active) {
    if (!mounted) return;
    if (active) {
      _openKeyboard();
    } else if (_keyboardOpen) {
      Navigator.of(context).pop(); // TV closed its keyboard
    }
  }

  // Reconnect when the user comes back to the app.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final tv = remote.device;
    if (state == AppLifecycleState.resumed &&
        tv != null &&
        (remote.status == RemoteStatus.disconnected ||
            remote.status == RemoteStatus.error)) {
      remote.connect(tv);
    }
  }

  Future<void> _restore() async {
    final tv = await remote.loadLastDevice();
    if (!mounted) return;
    if (tv != null) {
      remote.connect(tv);
    } else {
      _openDevices();
    }
  }

  void _openDevices() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => DevicesScreen(remote: remote),
    ));
  }

  void _key(String key) {
    if (!remote.sendKey(key)) _notConnected();
  }

  void _launch(String appId) {
    if (!remote.launchApp(appId)) _notConnected();
  }

  void _notConnected() {
    // Don't spam the snackbar while a key is held down.
    final now = DateTime.now();
    if (now.difference(_lastNotice).inSeconds < 2) return;
    _lastNotice = now;
    final tv = remote.device;
    _notice(
      'Not connected to a TV.',
      actionLabel: tv == null ? 'Choose TV' : 'Reconnect',
      onAction: tv == null ? _openDevices : () => remote.connect(tv),
    );
  }

  void _notice(String text, {String? actionLabel, VoidCallback? onAction}) {
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(
      content: Text(text),
      behavior: SnackBarBehavior.floating,
      action: (actionLabel != null && onAction != null)
          ? SnackBarAction(label: actionLabel, onPressed: onAction)
          : null,
    ));
  }

  Future<void> _power() async {
    if (!remote.isConnected && remote.device != null) {
      _notice('Turning the TV on…');
    }
    final err = await remote.power();
    if (err != null && mounted) _notice(err);
  }

  void _openNumbers() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Palette.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        Widget n(String label, String key) => Padding(
              padding: const EdgeInsets.all(6),
              child: RemoteKey(
                label: label,
                width: 84,
                height: 56,
                onPressed: () => _key(key),
                child: Text(label, style: const TextStyle(fontSize: 22)),
              ),
            );
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final row in const [
                  ['1', '2', '3'],
                  ['4', '5', '6'],
                  ['7', '8', '9'],
                ])
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [for (final d in row) n(d, 'KEY_$d')],
                  ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    n('-', 'KEY_PLUS100'),
                    n('0', 'KEY_0'),
                    Padding(
                      padding: const EdgeInsets.all(6),
                      child: RemoteKey(
                        label: 'Enter',
                        width: 84,
                        height: 56,
                        color: Palette.signal,
                        onPressed: () => _key('KEY_ENTER'),
                        child: const Icon(Icons.keyboard_return_rounded,
                            color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _switchInput(TvInput input) async {
    final ok = await remote.setInput(input);
    if (!mounted || ok) return;
    _notice(remote.lastError ?? 'The TV refused that input.');
  }

  /// The layout for a TV with no remote-control service: volume, mute and
  /// inputs, and nothing that pretends to be more than that.
  List<Widget> _limitedKeys() {
    final inputs = remote.inputs;
    final current = remote.currentInput;

    return [
      _StatusBanner(remote: remote, onChooseTv: _openDevices),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
        decoration: BoxDecoration(
          color: Palette.panel,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          'This TV is from before Samsung added remote control over Wi-Fi. '
          'It will change inputs and volume, but arrows, OK and power only '
          'work from the infrared remote.',
          style: TextStyle(
            color: Palette.muted.withAlpha(235),
            fontSize: 12.5,
            height: 1.4,
          ),
        ),
      ),
      const SizedBox(height: 20),
      Row(
        children: [
          Text('Input',
              style: TextStyle(color: Palette.muted.withAlpha(230), fontSize: 13)),
          const Spacer(),
          if (current != null)
            Text(current,
                style: const TextStyle(color: Palette.signal, fontSize: 13)),
        ],
      ),
      const SizedBox(height: 10),
      if (inputs.isEmpty)
        Text('The TV didn\'t list its inputs.',
            style: TextStyle(color: Palette.muted, fontSize: 13))
      else
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            for (final input in inputs)
              RemoteKey(
                label: 'Switch to ${input.label}',
                width: 104,
                height: 48,
                color: input.name == current ? Palette.signal : Palette.key,
                onPressed: () => _switchInput(input),
                child: Text(input.label, style: const TextStyle(fontSize: 14)),
              ),
          ],
        ),
      const SizedBox(height: 26),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Rocker(
              label: 'Vol',
              upKey: 'KEY_VOLUP',
              downKey: 'KEY_VOLDOWN',
              onKey: _key),
          Column(
            children: [
              RemoteKey(
                label: 'Mute',
                onPressed: () => _key('KEY_MUTE'),
                child: const Icon(Icons.volume_off_rounded),
              ),
              const SizedBox(height: 12),
              RemoteKey(
                label: 'Refresh inputs',
                onPressed: remote.refreshInputs,
                child: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
        ],
      ),
      const SizedBox(height: 12),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: remote,
      builder: (context, _) => Scaffold(
        backgroundColor: Palette.body,
        appBar: AppBar(
          backgroundColor: Palette.body,
          titleSpacing: 20,
          title: _Title(remote: remote),
          actions: [
            IconButton(
              tooltip: 'Choose TV',
              onPressed: _openDevices,
              icon: const Icon(Icons.cast_rounded),
            ),
            const SizedBox(width: 8),
          ],
        ),
        body: SafeArea(
          // A remote should be one screenful — reaching for a button should
          // never mean scrolling first. The layout is authored at a fixed
          // 360pt width and then scaled to whatever the phone actually has,
          // so every key stays visible and in the same relative place on a
          // small phone and a large one alike.
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: FittedBox(
              fit: BoxFit.contain,
              alignment: Alignment.topCenter,
              child: SizedBox(
                width: _designWidth,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  // A pre-2016 Samsung gets its own layout. Drawing a D-pad
                  // that physically cannot work would be worse than not
                  // drawing one — every button here does something.
                  children: remote.isLimitedRemote
                      ? _limitedKeys()
                      : [
                _StatusBanner(remote: remote, onChooseTv: _openDevices),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    RemoteKey(
                      label: 'Power',
                      color: Palette.power,
                      width: 56,
                      height: 56,
                      borderRadius: BorderRadius.circular(28),
                      onPressed: _power,
                      child: const Icon(Icons.power_settings_new_rounded,
                          color: Colors.white),
                    ),
                    RemoteKey(
                      label: 'Number pad',
                      width: 68,
                      onPressed: _openNumbers,
                      child: const Text('123'),
                    ),
                    RemoteKey(
                      label: 'Keyboard',
                      width: 68,
                      onPressed: _openKeyboard,
                      child: const Icon(Icons.keyboard_rounded),
                    ),
                    RemoteKey(
                      label: 'Source',
                      width: 68,
                      onPressed: () => _key('KEY_SOURCE'),
                      child: const Icon(Icons.input_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                DPad(onKey: _key),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    RemoteKey(
                      label: 'Back',
                      onPressed: () => _key('KEY_RETURN'),
                      child: const Icon(Icons.undo_rounded),
                    ),
                    RemoteKey(
                      label: 'Home',
                      onPressed: () => _key('KEY_HOME'),
                      child: const Icon(Icons.home_rounded),
                    ),
                    RemoteKey(
                      label: 'Settings menu',
                      onPressed: () => _key('KEY_MENU'),
                      child: const Icon(Icons.settings_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Rocker(
                        label: 'Vol',
                        upKey: 'KEY_VOLUP',
                        downKey: 'KEY_VOLDOWN',
                        onKey: _key),
                    Column(
                      children: [
                        RemoteKey(
                          label: 'Mute',
                          onPressed: () => _key('KEY_MUTE'),
                          child: const Icon(Icons.volume_off_rounded),
                        ),
                        const SizedBox(height: 12),
                        RemoteKey(
                          label: 'Guide',
                          onPressed: () => _key('KEY_GUIDE'),
                          child: const Icon(Icons.view_list_rounded),
                        ),
                      ],
                    ),
                    Rocker(
                        label: 'Ch',
                        upKey: 'KEY_CHUP',
                        downKey: 'KEY_CHDOWN',
                        onKey: _key),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Palette.panel,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      RemoteKey(
                        label: 'Rewind',
                        width: 60,
                        height: 46,
                        onPressed: () => _key('KEY_REWIND'),
                        child: const Icon(Icons.fast_rewind_rounded),
                      ),
                      RemoteKey(
                        label: 'Play',
                        width: 60,
                        height: 46,
                        onPressed: () => _key('KEY_PLAY'),
                        child: const Icon(Icons.play_arrow_rounded),
                      ),
                      RemoteKey(
                        label: 'Pause',
                        width: 60,
                        height: 46,
                        onPressed: () => _key('KEY_PAUSE'),
                        child: const Icon(Icons.pause_rounded),
                      ),
                      RemoteKey(
                        label: 'Fast forward',
                        width: 60,
                        height: 46,
                        onPressed: () => _key('KEY_FF'),
                        child: const Icon(Icons.fast_forward_rounded),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Open an app',
                      style: TextStyle(
                          color: Palette.muted.withAlpha(230), fontSize: 13)),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (final (name, id) in _apps)
                      RemoteKey(
                        label: 'Open $name',
                        width: 104,
                        height: 44,
                        borderRadius: BorderRadius.circular(22),
                        onPressed: () => _launch(id),
                        child: Text(name, style: const TextStyle(fontSize: 13)),
                      ),
                  ],
                ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Title extends StatelessWidget {
  final SamsungRemote remote;
  const _Title({required this.remote});

  @override
  Widget build(BuildContext context) {
    final color = switch (remote.status) {
      RemoteStatus.connected => Palette.signal,
      RemoteStatus.connecting || RemoteStatus.waitingForApproval => Palette.amber,
      RemoteStatus.error => Palette.power,
      RemoteStatus.disconnected => Palette.muted,
    };
    return Row(
      children: [
        Container(
          width: 9,
          height: 9,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 10),
        Flexible(
          child: Text(
            remote.device?.name ?? 'No TV selected',
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
                color: Palette.text, fontSize: 17, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }
}

class _StatusBanner extends StatelessWidget {
  final SamsungRemote remote;
  final VoidCallback onChooseTv;
  const _StatusBanner({required this.remote, required this.onChooseTv});

  @override
  Widget build(BuildContext context) {
    final tv = remote.device;
    String text = '';
    String? action;
    VoidCallback? onAction;
    Color accent = Palette.muted;

    switch (remote.status) {
      case RemoteStatus.connected:
        // Connected is normally silent — but a connection that succeeded on
        // the wrong port looks identical to a working one from here, and
        // hiding that warning is what made this take two rounds to spot.
        if (remote.onLegacyPortUnexpectedly && remote.lastError != null) {
          text = remote.lastError!;
          accent = Palette.amber;
          if (tv != null) {
            action = 'Retry';
            onAction = () => remote.connect(tv);
          }
          break;
        }
        return const SizedBox.shrink();
      case RemoteStatus.connecting:
        text = 'Connecting…';
      case RemoteStatus.waitingForApproval:
        text = 'Press Allow on your TV to pair this phone.';
        accent = Palette.amber;
      case RemoteStatus.error:
        text = remote.lastError ?? 'Connection failed.';
        accent = Palette.power;
        if (tv != null) {
          action = 'Retry';
          onAction = () => remote.connect(tv);
        }
      case RemoteStatus.disconnected:
        if (tv == null) {
          text = 'No TV selected.';
          action = 'Choose TV';
          onAction = onChooseTv;
        } else {
          text = 'Disconnected from ${tv.name}.';
          action = 'Reconnect';
          onAction = () => remote.connect(tv);
        }
    }

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(10, 10, 6, 10),
      decoration: BoxDecoration(
        color: Palette.panel,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 32,
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: accent,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Expanded(
            child: Text(text,
                style: const TextStyle(color: Palette.text, height: 1.35)),
          ),
          if (action != null && onAction != null)
            TextButton(onPressed: onAction, child: Text(action)),
        ],
      ),
    );
  }
}
