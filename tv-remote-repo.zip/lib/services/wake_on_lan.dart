import 'dart:io';
import 'dart:typed_data';

/// Sends a Wake-on-LAN "magic packet" to power the TV on.
///
/// TV side: enable Settings > General > Network > Expert Settings >
/// "Power On with Mobile" (name varies by model).
/// iOS side: broadcast needs Apple's multicast entitlement.
class WakeOnLan {
  static Future<void> wake(String mac, {String? tvIp}) async {
    final hex = mac.replaceAll(RegExp(r'[^0-9a-fA-F]'), '');
    if (hex.length != 12) {
      throw ArgumentError('Invalid MAC address: $mac');
    }
    final macBytes = [
      for (var i = 0; i < 12; i += 2)
        int.parse(hex.substring(i, i + 2), radix: 16),
    ];

    // 6 x 0xFF, then the MAC repeated 16 times.
    final packet = Uint8List(102);
    for (var i = 0; i < 6; i++) {
      packet[i] = 0xFF;
    }
    for (var r = 0; r < 16; r++) {
      packet.setRange(6 + r * 6, 12 + r * 6, macBytes);
    }

    final targets = <InternetAddress>[InternetAddress('255.255.255.255')];
    if (tvIp != null) {
      final p = tvIp.split('.');
      if (p.length == 4) {
        targets.add(InternetAddress('${p[0]}.${p[1]}.${p[2]}.255'));
        targets.add(InternetAddress(tvIp));
      }
    }

    final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    try {
      socket.broadcastEnabled = true;
      for (var round = 0; round < 3; round++) {
        for (final t in targets) {
          try {
            socket.send(packet, t, 9);
          } catch (_) {
            // One target failing (e.g. broadcast blocked) shouldn't stop the rest.
          }
        }
        await Future.delayed(const Duration(milliseconds: 150));
      }
    } finally {
      socket.close();
    }
  }
}
