import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/tv_device.dart';
import 'atv/android_tv.dart';
import 'atv/atv_crypto.dart';
import 'wake_on_lan.dart';

enum RemoteStatus { disconnected, connecting, waitingForApproval, connected, error }

/// Handshake failed after the socket opened (denied, timed out).
/// Don't retry on the other port in this case.
class _HandshakeError implements Exception {
  final String message;
  _HandshakeError(this.message);
  @override
  String toString() => message;
}

/// Talks to a Samsung Tizen TV over its local WebSocket remote API.
///
/// Two generations of TV, two different ports:
///
///   2018 and newer -> wss://<ip>:8002, self-signed certificate, and the TV
///                     shows an "Allow" box the first time. It hands back a
///                     token that is reused on later connections.
///   2016-2017      -> ws://<ip>:8001, plain, no token, no prompt.
///
/// The trap: a 2018+ TV still ACCEPTS a plain connection on 8001 and reports
/// it as connected. It just ignores every command sent over it. So falling
/// back to 8001 when 8002 fails produces a remote that looks connected and
/// does nothing. We only fall back when port 8002 is genuinely closed.
class SamsungRemote extends ChangeNotifier {
  static const _appName = 'Flutter TV Remote';
  static const _lastDeviceKey = 'last_device';

  WebSocket? _ws;
  Completer<void>? _handshake;

  /// Set when the connected TV is a Google TV rather than a Samsung.
  AndroidTvRemote? _atv;

  /// Supplied by the UI. Called when a Google TV puts its six-character
  /// pairing code on screen; returns what the user typed, or null to cancel.
  Future<String?> Function()? onPairingCodeRequested;

  TvDevice? device;
  RemoteStatus status = RemoteStatus.disconnected;
  String? lastError;

  /// The URL that is actually carrying commands, e.g. "wss://192.168.1.5:8002".
  /// Useful when the remote connects but nothing responds.
  String? connectedUrl;

  /// Set when we had to drop to the legacy port on a TV that claims to want
  /// token auth. Commands will probably be ignored; worth telling the user.
  bool onLegacyPortUnexpectedly = false;

  // true = a text field on the TV is focused (on models that report it).
  final _imeController = StreamController<bool>.broadcast();
  Stream<bool> get imeActive => _imeController.stream;

  bool get isConnected => status == RemoteStatus.connected;

  // ---------- Saved device ----------

  Future<TvDevice?> loadLastDevice() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_lastDeviceKey);
    if (raw == null) return null;
    try {
      return TvDevice.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> _saveLastDevice(TvDevice tv) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastDeviceKey, jsonEncode(tv.toJson()));
  }

  String _tokenKey(String ip) => 'token_$ip';

  /// Google TV: the client certificate, which IS the pairing.
  String _identityKey(String ip) => 'atv_identity_$ip';

  // ---------- Connection ----------

  /// Returns true if connected. On failure, [lastError] explains why.
  Future<bool> connect(TvDevice tv) async {
    await disconnect();
    device = tv;
    lastError = null;
    connectedUrl = null;
    onLegacyPortUnexpectedly = false;
    _setStatus(RemoteStatus.connecting);
    await _saveLastDevice(tv);

    if (tv.brand == TvBrand.androidTv) {
      return _connectAndroidTv(tv);
    }

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString(_tokenKey(tv.ip));
    final name = Uri.encodeQueryComponent(base64Encode(utf8.encode(_appName)));
    const path = '/api/v2/channels/samsung.remote.control';
    final tokenPart = token != null ? '&token=$token' : '';

    final secure = 'wss://${tv.ip}:8002$path?name=$name$tokenPart';
    final legacy = 'ws://${tv.ip}:8001$path?name=$name';

    // Always try the secure port first, whatever the TV reported about token
    // auth: some 2018+ models omit the TokenAuthSupport flag entirely, and
    // trusting that flag would send them to the dead legacy port. A genuine
    // 2016-2017 TV simply has 8002 closed, which the fallback below catches.
    try {
      await _open(secure, tv.ip);
      return true;
    } on _HandshakeError catch (e) {
      // The TV answered and said no. Retrying on 8001 would "succeed" and
      // then ignore everything, so stop here and say what happened.
      return _fail(e.message);
    } on HandshakeException catch (e) {
      // TLS problem, not a missing port. Falling back would hide it.
      return _fail('Secure connection to the TV failed: ${e.message}. '
          'The app can reach the TV but could not complete the encrypted '
          'handshake on port 8002.');
    } on SocketException catch (e) {
      // Port 8002 closed or unreachable. Could be an older TV after all.
      try {
        await _open(legacy, tv.ip);
        if (tv.tokenAuth) {
          // The TV said it wants token auth but its secure port is shut.
          // Commands on 8001 will most likely be ignored, so say so rather
          // than presenting a remote that looks fine and does nothing.
          onLegacyPortUnexpectedly = true;
          lastError = 'Connected on the older port 8001 because port 8002 was '
              'closed. This TV asked for the secure port, so buttons may do '
              'nothing. On the TV try Settings > General > Network > Expert '
              'Settings and check IP Settings, or restart the TV.';
          notifyListeners();
        }
        return true;
      } on _HandshakeError catch (e2) {
        return _fail(e2.message);
      } catch (_) {
        return _fail(_unreachable(tv.ip, e));
      }
    } catch (e) {
      return _fail('Could not connect to the TV on port 8002: $e');
    }
  }

  /// Google TV: pair once, then open the command channel.
  ///
  /// The client certificate is the credential — there is no token. Once the
  /// TV trusts it, later connections skip the code entirely.
  Future<bool> _connectAndroidTv(TvDevice tv) async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString(_identityKey(tv.ip));

    ClientIdentity? identity;
    if (stored != null) {
      try {
        identity = ClientIdentity.fromJson(jsonDecode(stored) as Map<String, dynamic>);
      } catch (_) {
        identity = null; // corrupt, pair again
      }
    }

    final freshPairing = identity == null;

    try {
      if (identity == null) {
        final ask = onPairingCodeRequested;
        if (ask == null) {
          return _fail('This TV needs pairing, but the app can\'t ask for the code right now.');
        }
        _setStatus(RemoteStatus.waitingForApproval);
        // RSA-2048 in pure Dart takes a few seconds; it runs off the UI thread.
        identity = await AtvCrypto.generateIdentity();
        await AndroidTvRemote.pair(
          ip: tv.ip,
          identity: identity,
          onCodeRequested: ask,
        );
        await prefs.setString(_identityKey(tv.ip), jsonEncode(identity.toJson()));
      }

      final atv = AndroidTvRemote();
      await atv.connect(ip: tv.ip, identity: identity);
      _atv = atv;

      // The TV's certificate carries its MAC. Keep it, so the power button
      // can wake the TV later instead of giving up.
      final mac = atv.serverMac;
      if (mac != null && mac != tv.mac) {
        final updated = tv.copyWith(mac: mac);
        device = updated;
        await _saveLastDevice(updated);
      }
      connectedUrl = 'wss://${tv.ip}:${AndroidTvRemote.commandPort}';
      _setStatus(RemoteStatus.connected);
      return true;
    } on AtvException catch (e) {
      await _closeAtv();
      // A stored pairing the TV no longer honours: drop it so the next
      // attempt starts a fresh one instead of failing the same way forever.
      if (!freshPairing) {
        await prefs.remove(_identityKey(tv.ip));
        return _fail('${e.message}\n\nThe saved pairing has been cleared — try connecting again.');
      }
      return _fail(e.message);
    } catch (e) {
      await _closeAtv();
      return _fail('Couldn\'t connect to the TV: $e');
    }
  }

  Future<void> _closeAtv() async {
    final atv = _atv;
    _atv = null;
    await atv?.disconnect();
  }

  String _unreachable(String ip, Object e) =>
      'Can\'t reach the TV at $ip. Check it is on and on the same Wi-Fi. ($e)';

  Future<void> _open(String url, String host) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 8)
      // Samsung TVs present a self-signed certificate whose hostname never
      // matches the IP we dial. This client is used for exactly one
      // connection, to the address the user chose, so accept it.
      ..badCertificateCallback = (cert, certHost, port) => true;

    final ws = await WebSocket.connect(url, customClient: client)
        .timeout(const Duration(seconds: 10));
    _ws = ws;
    connectedUrl = url.split('?').first;
    ws.pingInterval = const Duration(seconds: 15);

    final handshake = Completer<void>();
    _handshake = handshake;
    _setStatus(RemoteStatus.waitingForApproval);

    ws.listen(
      _onMessage,
      onDone: () => _onClosed(ws),
      onError: (_) => _onClosed(ws),
      cancelOnError: true,
    );

    try {
      await handshake.future.timeout(const Duration(seconds: 30));
    } on TimeoutException {
      _handshake = null;
      _ws = null;
      await ws.close();
      throw _HandshakeError(
          'No reply from the TV. Try again and press Allow on the TV screen.');
    }
  }

  void _onMessage(dynamic raw) {
    if (raw is! String) return;
    Map<String, dynamic> msg;
    try {
      msg = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }

    switch (msg['event']) {
      case 'ms.channel.connect':
        final data = msg['data'];
        final token = data is Map ? data['token']?.toString() : null;
        final d = device;
        if (token != null && token.isNotEmpty && d != null) {
          SharedPreferences.getInstance()
              .then((p) => p.setString(_tokenKey(d.ip), token));
        }
        _completeHandshake();
        _setStatus(RemoteStatus.connected);
        break;

      case 'ms.channel.unauthorized':
        final dev = device;
        if (dev != null) {
          SharedPreferences.getInstance().then((p) => p.remove(_tokenKey(dev.ip)));
        }
        _failHandshake('The TV blocked this phone. On the TV, go to Settings > '
            'General > External Device Manager > Device Connection Manager, '
            'remove it from the blocked list, then try again.');
        break;

      case 'ms.channel.timeOut':
        _failHandshake('The TV prompt timed out. Try again and press Allow.');
        break;

      case 'ms.remote.imeStart':
        _imeController.add(true);
        break;

      case 'ms.remote.imeEnd':
      case 'ms.remote.imeDone':
        _imeController.add(false);
        break;
    }
  }

  void _onClosed(WebSocket closed) {
    // Ignore late close events from an older socket.
    if (!identical(_ws, closed)) return;
    _ws = null;
    connectedUrl = null;
    _failHandshake('Connection closed by the TV.');
    if (status == RemoteStatus.connected) {
      _setStatus(RemoteStatus.disconnected);
    }
  }

  void _completeHandshake() {
    final h = _handshake;
    if (h != null && !h.isCompleted) h.complete();
  }

  void _failHandshake(String message) {
    final h = _handshake;
    if (h != null && !h.isCompleted) h.completeError(_HandshakeError(message));
  }

  bool _fail(String message) {
    lastError = message;
    connectedUrl = null;
    _ws?.close();
    _ws = null;
    _setStatus(RemoteStatus.error);
    return false;
  }

  Future<void> disconnect() async {
    await _closeAtv();
    final ws = _ws;
    _ws = null;
    connectedUrl = null;
    if (ws != null) await ws.close();
    if (status != RemoteStatus.disconnected) {
      _setStatus(RemoteStatus.disconnected);
    }
  }

  /// Drops the saved pairing token so the next connect starts a fresh pairing
  /// and the TV shows its Allow box again.
  Future<void> forgetPairing() async {
    final d = device;
    if (d == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey(d.ip));
  }

  // ---------- Commands ----------

  /// Sends a remote key, e.g. KEY_VOLUP. Returns false if not connected.
  bool sendKey(String key, {String cmd = 'Click'}) {
    final atv = _atv;
    if (atv != null) {
      final code = AndroidKeys.codeFor(key);
      if (code == null) {
        lastError = 'This TV has no equivalent of that button.';
        notifyListeners();
        return false;
      }
      return atv.sendKeyCode(code);
    }

    return _send({
      'method': 'ms.remote.control',
      'params': {
        'Cmd': cmd, // Click | Press | Release
        'DataOfCmd': key,
        'Option': 'false',
        'TypeOfRemote': 'SendRemoteKey',
      },
    });
  }

  /// Opens an installed TV app. App IDs vary by region/model.
  bool launchApp(String appId, {String actionType = 'DEEP_LINK'}) {
    final atv = _atv;
    if (atv != null) {
      final link = AndroidAppLinks.linkFor(appId);
      if (link == null) {
        lastError = 'That app isn\'t mapped for Google TV yet.';
        notifyListeners();
        return false;
      }
      return atv.launchAppLink(link);
    }
    return _send({
      'method': 'ms.channel.emit',
      'params': {
        'event': 'ed.apps.launch',
        'to': 'host',
        'data': {'appId': appId, 'action_type': actionType},
      },
    });
  }

  /// Types [text] into the focused text field on the TV.
  /// Select a search box / text field on the TV first.
  bool sendText(String text) {
    final atv = _atv;
    if (atv != null) return atv.sendTextAsKeys(text);
    return _send({
      'method': 'ms.remote.control',
      'params': {
        'Cmd': base64Encode(utf8.encode(text)),
        'DataOfCmd': 'base64',
        'TypeOfRemote': 'SendInputString',
      },
    });
  }

  /// Tells the TV typing is finished (closes its on-screen keyboard).
  bool endInput() {
    final atv = _atv;
    if (atv != null) {
      // No "done" message; BACK dismisses the TV's keyboard.
      final back = AndroidKeys.codeFor('KEY_RETURN');
      return back != null && atv.sendKeyCode(back);
    }
    return _send({
      'method': 'ms.remote.control',
      'params': {'TypeOfRemote': 'SendInputEnd'},
    });
  }

  /// Off when connected; Wake-on-LAN + reconnect when not.
  Future<String?> power() async {
    if (isConnected) {
      sendKey('KEY_POWER');
      return null;
    }
    final d = device;
    if (d == null) return 'Pick a TV first.';

    final mac = d.mac;
    if (mac == null) {
      // Google TV only reveals its MAC inside the certificate it presents,
      // so we learn it the first time we successfully connect.
      return d.brand == TvBrand.androidTv
          ? 'Connect to this TV once while it\'s switched on. After that the '
              'power button can wake it.'
          : 'This TV didn\'t share its MAC address, so it can\'t be turned on remotely.';
    }
    try {
      await WakeOnLan.wake(mac, tvIp: d.ip);
    } catch (e) {
      return 'Couldn\'t send the wake signal: $e';
    }
    // Give the TV time to boot its network stack, then reconnect.
    await Future.delayed(const Duration(seconds: 6));
    final ok = await connect(d);
    if (ok) return null;
    return d.brand == TvBrand.androidTv
        ? 'Wake signal sent, but the TV didn\'t answer. On the TV, turn on '
            'Settings > System > Power & Energy > Network standby (sometimes '
            'called Quick start or Wake on LAN).'
        : 'Wake signal sent, but the TV didn\'t respond. Enable "Power On with Mobile" on the TV.';
  }

  bool _send(Map<String, dynamic> payload) {
    final ws = _ws;
    if (ws == null || !isConnected) return false;
    ws.add(jsonEncode(payload));
    return true;
  }

  void _setStatus(RemoteStatus s) {
    status = s;
    notifyListeners();
  }

  @override
  void dispose() {
    _imeController.close();
    _ws?.close();
    super.dispose();
  }
}
