import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// Controls a pre-2016 Samsung TV over UPnP.
///
/// These sets have no key injection at all. Their WebSocket message bus
/// answers `ms.remote.control` with "unrecognized method" — Samsung only
/// added remote keys in 2016. What they DO have is UPnP on port 7676, and
/// two services on it that take orders:
///
///   RenderingControl            volume and mute
///   samsung.com:MainTVAgent2    input switching, channels
///
/// Verified against a UA55H6400 (2014 H-series): reading the volume works,
/// SetMute works, and SetMainTVSource physically changes the input.
///
/// The consequence for the UI: there is no Up/Down/Left/Right/OK/Back/Menu
/// on this kind of TV, and no power. Don't draw buttons that can't work.
class SamsungUpnp {
  SamsungUpnp(this.ip);

  final String ip;

  /// Where the device descriptions live. Samsung numbers them unpredictably,
  /// so we read all four and take whatever services turn up.
  static const _descriptionPaths = ['smp_2_', 'smp_7_', 'smp_15_', 'smp_25_'];

  /// The TV is noticeably more cooperative when it believes it's talking to a
  /// Samsung phone rather than an unknown HTTP client.
  static const _userAgent = 'DLNADOC/1.50 SEC_HHP_Android/1.0';

  static const _renderingType = 'urn:schemas-upnp-org:service:RenderingControl:1';
  static const _agentType = 'urn:samsung.com:service:MainTVAgent2:1';

  String? _renderingUrl;
  String? _agentUrl;

  /// Inputs the TV reports, in the order it lists them.
  List<TvInput> inputs = const [];

  /// The input currently showing, e.g. "HDMI1". Null until known.
  String? currentInput;

  bool get hasVolume => _renderingUrl != null;
  bool get hasInputs => _agentUrl != null;

  /// Reads the TV's own service list. Must succeed before anything else works.
  Future<bool> discover() async {
    for (final path in _descriptionPaths) {
      final body = await _get('http://$ip:7676/$path');
      if (body == null) continue;

      for (final match in RegExp(r'<service>(.*?)</service>', dotAll: true).allMatches(body)) {
        final block = match.group(1)!;
        final type = _tag(block, 'serviceType');
        final control = _tag(block, 'controlURL');
        if (type == null || control == null) continue;

        final url = control.startsWith('http')
            ? control
            : Uri.parse('http://$ip:7676/$path').resolve(control).toString();

        if (type.contains('RenderingControl')) {
          _renderingUrl ??= url;
        } else if (type.contains('MainTVAgent2')) {
          _agentUrl ??= url;
        }
      }
    }

    // Samsung's numbering has been stable across this generation, so fall
    // back to the known addresses rather than giving up.
    _renderingUrl ??= 'http://$ip:7676/smp_17_';
    _agentUrl ??= 'http://$ip:7676/smp_4_';

    return true;
  }

  // ---------- volume ----------

  Future<int?> getVolume() async {
    final url = _renderingUrl;
    if (url == null) return null;
    final reply = await _soap(
      url: url,
      service: _renderingType,
      action: 'GetVolume',
      body: '<InstanceID>0</InstanceID><Channel>Master</Channel>',
    );
    if (reply == null) return null;
    final value = _tag(reply, 'CurrentVolume');
    return value == null ? null : int.tryParse(value);
  }

  Future<bool> setVolume(int level) async {
    final url = _renderingUrl;
    if (url == null) return false;
    final clamped = level.clamp(0, 100);
    final reply = await _soap(
      url: url,
      service: _renderingType,
      action: 'SetVolume',
      body: '<InstanceID>0</InstanceID><Channel>Master</Channel>'
          '<DesiredVolume>$clamped</DesiredVolume>',
    );
    return reply != null;
  }

  /// Volume up/down. The TV has no step command, so read the current level
  /// and set the next one.
  Future<bool> nudgeVolume(int delta) async {
    final now = await getVolume();
    if (now == null) return false;
    return setVolume(now + delta);
  }

  Future<bool> setMute(bool muted) async {
    final url = _renderingUrl;
    if (url == null) return false;
    final reply = await _soap(
      url: url,
      service: _renderingType,
      action: 'SetMute',
      body: '<InstanceID>0</InstanceID><Channel>Master</Channel>'
          '<DesiredMute>${muted ? 1 : 0}</DesiredMute>',
    );
    return reply != null;
  }

  Future<bool?> isMuted() async {
    final url = _renderingUrl;
    if (url == null) return null;
    final reply = await _soap(
      url: url,
      service: _renderingType,
      action: 'GetMute',
      body: '<InstanceID>0</InstanceID><Channel>Master</Channel>',
    );
    if (reply == null) return null;
    final value = _tag(reply, 'CurrentMute');
    return value == '1' || value?.toLowerCase() == 'true';
  }

  // ---------- inputs ----------

  /// Fetches the input list and which one is showing.
  Future<bool> refreshInputs() async {
    final url = _agentUrl;
    if (url == null) return false;

    final reply = await _soap(url: url, service: _agentType, action: 'GetSourceList');
    if (reply == null) return false;

    // The list arrives as XML escaped inside the SOAP response.
    final inner = _unescape(reply);
    final found = <TvInput>[];
    for (final match in RegExp(r'<Source>(.*?)</Source>', dotAll: true).allMatches(inner)) {
      final block = match.group(1)!;
      final name = _tag(block, 'SourceType');
      final id = _tag(block, 'ID');
      if (name == null || id == null) continue;
      final number = int.tryParse(id);
      if (number == null) continue;
      found.add(TvInput(name: name, id: number));
    }
    if (found.isNotEmpty) inputs = found;

    final current = await _soap(
      url: url,
      service: _agentType,
      action: 'GetCurrentExternalSource',
    );
    if (current != null) {
      currentInput = _tag(current, 'CurrentExternalSource');
    }

    return inputs.isNotEmpty;
  }

  /// Switches the TV to [input]. Verified working on the H-series.
  Future<bool> setInput(TvInput input) async {
    final url = _agentUrl;
    if (url == null) return false;
    final reply = await _soap(
      url: url,
      service: _agentType,
      action: 'SetMainTVSource',
      body: '<Source>${input.name}</Source><ID>${input.id}</ID><UiID>0</UiID>',
    );
    if (reply == null) return false;
    currentInput = input.name;
    return true;
  }

  // ---------- plumbing ----------

  /// Last SOAP failure in words, for the UI to show.
  String? lastError;

  Future<String?> _soap({
    required String url,
    required String service,
    required String action,
    String body = '',
  }) async {
    final envelope =
        '<?xml version="1.0" encoding="utf-8"?>'
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
        's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
        '<s:Body><u:$action xmlns:u="$service">$body</u:$action></s:Body>'
        '</s:Envelope>';

    final client = HttpClient()..connectionTimeout = const Duration(seconds: 6);
    try {
      final request = await client.postUrl(Uri.parse(url));
      request.headers.set(HttpHeaders.contentTypeHeader, 'text/xml; charset="utf-8"');
      request.headers.set(HttpHeaders.userAgentHeader, _userAgent);
      request.headers.set('SOAPACTION', '"$service#$action"');
      request.add(utf8.encode(envelope));

      final response = await request.close().timeout(const Duration(seconds: 8));
      final text = await response.transform(utf8.decoder).join();

      if (response.statusCode >= 200 && response.statusCode < 300) {
        lastError = null;
        return text;
      }

      // A UPnP failure carries its reason in the fault body, which is far
      // more useful than the HTTP status on its own.
      final code = _tag(text, 'errorCode');
      final description = _tag(text, 'errorDescription');
      lastError = description != null
          ? '$action failed: $description${code != null ? ' (UPnP $code)' : ''}'
          : '$action failed (HTTP ${response.statusCode})';
      return null;
    } on TimeoutException {
      lastError = 'The TV didn\'t answer in time.';
      return null;
    } catch (e) {
      lastError = 'Couldn\'t reach the TV: $e';
      return null;
    } finally {
      client.close(force: true);
    }
  }

  Future<String?> _get(String url) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 5);
    try {
      final request = await client.getUrl(Uri.parse(url));
      request.headers.set(HttpHeaders.userAgentHeader, _userAgent);
      final response = await request.close().timeout(const Duration(seconds: 6));
      if (response.statusCode != 200) return null;
      return await response.transform(utf8.decoder).join();
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }

  static String? _tag(String source, String name) {
    final match = RegExp('<$name>(.*?)</$name>', dotAll: true).firstMatch(source);
    return match?.group(1)?.trim();
  }

  static String _unescape(String s) => s
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'")
      .replaceAll('&amp;', '&');
}

/// One selectable input on the TV. The id comes from the TV's own list and
/// is required when switching — the name alone is not enough.
class TvInput {
  const TvInput({required this.name, required this.id});

  final String name;
  final int id;

  /// What to put on the button. The TV's own names are terse.
  String get label {
    switch (name.toUpperCase()) {
      case 'TV':
        return 'TV';
      case 'AV':
        return 'AV';
      case 'COMPONENT':
        return 'Comp';
      case 'HDMI4/DVI':
        return 'HDMI4';
      default:
        return name;
    }
  }

  @override
  bool operator ==(Object other) =>
      other is TvInput && other.name == name && other.id == id;

  @override
  int get hashCode => Object.hash(name, id);
}
