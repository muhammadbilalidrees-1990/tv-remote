import 'dart:typed_data';

/// The slice of protobuf the Android TV remote protocol actually uses:
/// varints, length-delimited fields, and frames prefixed with their length.
///
/// Hand-rolled on purpose. Generating Dart from the .proto files would mean
/// running protoc during the build, and the message set here is six messages
/// wide.
class Pb {
  /// Standard protobuf varint: 7 bits per byte, high bit means "more".
  static Uint8List varint(int value) {
    final out = <int>[];
    var v = value;
    while (v > 0x7F) {
      out.add((v & 0x7F) | 0x80);
      v >>= 7;
    }
    out.add(v);
    return Uint8List.fromList(out);
  }

  static Uint8List join(List<List<int>> parts) {
    final out = <int>[];
    for (final p in parts) {
      out.addAll(p);
    }
    return Uint8List.fromList(out);
  }

  /// A varint field: `tag | wire type 0`.
  static Uint8List varintField(int field, int value) =>
      join([varint(field << 3), varint(value)]);

  /// A length-delimited field: `tag | wire type 2`.
  static Uint8List bytesField(int field, List<int> payload) =>
      join([varint((field << 3) | 2), varint(payload.length), payload]);

  static Uint8List stringField(int field, String text) =>
      bytesField(field, text.codeUnits);

  /// Wraps a payload in its length prefix, ready for the socket.
  static Uint8List frame(List<int> payload) =>
      join([varint(payload.length), payload]);
}

/// Reads length-prefixed frames out of a byte stream that arrives in
/// arbitrary chunks. TCP gives no message boundaries, so a frame can be split
/// across reads or several frames can land in one.
class FrameReader {
  final _buffer = <int>[];

  void add(List<int> chunk) => _buffer.addAll(chunk);

  /// Returns every complete frame currently buffered, consuming them.
  List<Uint8List> drain() {
    final frames = <Uint8List>[];

    while (true) {
      // Parse the length varint without consuming it yet — the body may not
      // have arrived.
      var length = 0;
      var shift = 0;
      var i = 0;
      var complete = false;

      while (i < _buffer.length) {
        final b = _buffer[i];
        length |= (b & 0x7F) << shift;
        i++;
        if ((b & 0x80) == 0) {
          complete = true;
          break;
        }
        shift += 7;
        if (shift > 28) return frames; // malformed, give up
      }

      if (!complete) return frames; // length prefix still incomplete
      if (_buffer.length - i < length) return frames; // body still incomplete

      frames.add(Uint8List.fromList(_buffer.sublist(i, i + length)));
      _buffer.removeRange(0, i + length);
      if (_buffer.isEmpty) return frames;
    }
  }
}

/// Top-level fields of a protobuf message: field number to value.
/// Varint fields come back as int, length-delimited ones as Uint8List.
/// Nested messages are not decoded — nothing here needs them.
Map<int, Object> parseFields(Uint8List data) {
  final fields = <int, Object>{};
  var i = 0;

  int? readVarint() {
    var value = 0;
    var shift = 0;
    while (i < data.length) {
      final b = data[i];
      i++;
      value |= (b & 0x7F) << shift;
      if ((b & 0x80) == 0) return value;
      shift += 7;
      if (shift > 35) return null;
    }
    return null;
  }

  while (i < data.length) {
    final tag = readVarint();
    if (tag == null) break;
    final field = tag >> 3;
    final wire = tag & 7;

    if (wire == 0) {
      final v = readVarint();
      if (v == null) break;
      fields[field] = v;
    } else if (wire == 2) {
      final len = readVarint();
      if (len == null || i + len > data.length) break;
      fields[field] = Uint8List.sublistView(data, i, i + len);
      i += len;
    } else if (wire == 5) {
      i += 4;
    } else if (wire == 1) {
      i += 8;
    } else {
      break; // groups: not used by this protocol
    }
  }

  return fields;
}
