import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'atv_crypto.dart';
import 'protobuf.dart';

/// Android TV / Google TV remote, protocol v2.
///
/// Verified against a TCL G07_4K_GB_NF. Two TLS ports, both needing a client
/// certificate that the TV comes to trust during pairing:
///
///   6467  pairing, once per TV. The TV shows a 6-character code.
///   6466  commands, every session after that.
///
/// See claude/android-tv-protocol-verified.md in the project for the wire
/// format and the traps.
class AndroidTvRemote {
  static const pairingPort = 6467;
  static const commandPort = 6466;

  static const _serviceName = 'com.bilal.tvremote';
  static const _clientName = 'TV Remote';

  SecureSocket? _socket;

  /// The TV's MAC address, lifted from its certificate subject. Google TV
  /// never reports it over the protocol, but it signs its certificate with
  /// something like "CN=atvremote/G07_4K/Smart TV/E0:01:C7:99:F1:97" — and
  /// that is exactly what Wake-on-LAN needs.
  String? serverMac;

  final _reader = FrameReader();
  StreamSubscription<Uint8List>? _subscription;
  Completer<Uint8List>? _awaiting;

  bool get isConnected => _socket != null;

  // ---------------------------------------------------------------- pairing

  /// Runs the pairing handshake. [onCodeRequested] is called once the TV puts
  /// its code on screen; return the six characters the user typed, or null to
  /// give up.
  ///
  /// Throws [AtvException] with something readable on failure.
  /// Digs a MAC address out of a certificate subject line.
  static String? macFromSubject(String? subject) {
    if (subject == null) return null;
    final match = RegExp(r'([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}').firstMatch(subject);
    return match?.group(0)?.toUpperCase();
  }

  /// Returns the TV's MAC address if its certificate revealed one.
  static Future<String?> pair({
    required String ip,
    required ClientIdentity identity,
    required Future<String?> Function() onCodeRequested,
    Duration timeout = const Duration(seconds: 15),
  }) async {
    final session = AndroidTvRemote();
    await session._open(ip, pairingPort, identity, timeout);

    try {
      // 1. PairingRequest (field 10)
      await session._exchange(Pb.join([
        _pairingBase(),
        Pb.bytesField(10, Pb.join([
          Pb.stringField(1, _serviceName),
          Pb.stringField(2, _clientName),
        ])),
      ]), 'pairing request');

      // 2. PairingOption (field 20): hexadecimal, six symbols, input role
      final encoding = Pb.join([Pb.varintField(1, 3), Pb.varintField(2, 6)]);
      await session._exchange(Pb.join([
        _pairingBase(),
        Pb.bytesField(20, Pb.join([
          Pb.bytesField(1, encoding),
          Pb.varintField(3, 1),
        ])),
      ]), 'pairing options');

      // 3. PairingConfiguration (field 30) — the TV shows its code after this
      await session._exchange(Pb.join([
        _pairingBase(),
        Pb.bytesField(30, Pb.join([
          Pb.bytesField(1, encoding),
          Pb.varintField(2, 1),
        ])),
      ]), 'pairing configuration');

      // 4. the code
      final typed = await onCodeRequested();
      final code = (typed ?? '').toUpperCase().replaceAll(RegExp('[^0-9A-F]'), '');
      if (code.length != 6) {
        throw const AtvException('That code needs to be the six characters shown on the TV.');
      }

      final serverCertificate = session._socket?.peerCertificate;
      if (serverCertificate == null) {
        throw const AtvException('The TV did not present a certificate.');
      }

      final secret = AtvCrypto.pairingSecret(
        client: AtvCrypto.numbersFromPem(identity.certificatePem),
        server: AtvCrypto.numbersFromDer(Uint8List.fromList(serverCertificate.der)),
        code: code,
      );

      // The first two characters of the code are a checksum over the secret.
      // Catching a mismatch here saves burning a pairing attempt on the TV.
      if (!AtvCrypto.verifyChecksum(secret, code)) {
        throw const AtvException('That code did not match. Check the characters and try again.');
      }

      // 5. PairingSecret (field 40)
      await session._exchange(Pb.join([
        _pairingBase(),
        Pb.bytesField(40, Pb.bytesField(1, secret)),
      ]), 'pairing secret');

      return session.serverMac;
    } finally {
      await session.disconnect();
    }
  }

  /// Every PairingMessage carries protocol_version 2 and status OK.
  static Uint8List _pairingBase() =>
      Pb.join([Pb.varintField(1, 2), Pb.varintField(2, 200)]);

  // ---------------------------------------------------------------- commands

  /// Opens the command channel. The TV must already trust this identity.
  Future<void> connect({
    required String ip,
    required ClientIdentity identity,
    Duration timeout = const Duration(seconds: 10),
  }) async {
    await _open(ip, commandPort, identity, timeout);

    // The TV speaks first.
    await _receive(timeout, 'the TV\'s greeting');

    // RemoteConfigure (field 1)
    final deviceInfo = Pb.join([
      Pb.stringField(1, 'TV Remote'),
      Pb.stringField(2, 'bilal'),
      Pb.varintField(3, 1),
      Pb.stringField(4, '1'),
      Pb.stringField(5, _serviceName),
      Pb.stringField(6, '1.0.0'),
    ]);
    _send(Pb.bytesField(1, Pb.join([
      Pb.varintField(1, 622),
      Pb.bytesField(2, deviceInfo),
    ])));
    await _receive(timeout, 'the configuration reply');

    // RemoteSetActive (field 2)
    _send(Pb.bytesField(2, Pb.varintField(1, 622)));
  }

  /// Sends one key press. [keyCode] is an Android KeyEvent constant.
  bool sendKeyCode(int keyCode) {
    if (_socket == null) return false;
    // RemoteKeyInject (field 10): key_code, direction SHORT = 3
    _send(Pb.bytesField(10, Pb.join([
      Pb.varintField(1, keyCode),
      Pb.varintField(2, 3),
    ])));
    return true;
  }

  /// Opens an app by its deep link, e.g. "https://www.youtube.com".
  /// RemoteAppLinkLaunchRequest is field 90.
  bool launchAppLink(String link) {
    if (_socket == null) return false;
    _send(Pb.bytesField(90, Pb.stringField(1, link)));
    return true;
  }

  /// Types [text] by injecting one key event per character.
  ///
  /// Google TV has no "send this string" message that works reliably across
  /// launchers, but a focused text field accepts ordinary key events, which
  /// is what a physical remote's keyboard sends anyway. Case is dropped —
  /// there is no modifier field in RemoteKeyInject, and search boxes don't
  /// care.
  bool sendTextAsKeys(String text) {
    if (_socket == null) return false;
    for (final char in text.toLowerCase().split('')) {
      final code = AndroidKeys.codeForCharacter(char);
      if (code == null) continue; // silently skip what we can't type
      sendKeyCode(code);
    }
    return true;
  }

  // ---------------------------------------------------------------- plumbing

  Future<void> _open(String ip, int port, ClientIdentity identity, Duration timeout) async {
    final context = SecurityContext(withTrustedRoots: false)
      ..useCertificateChainBytes(utf8.encode(identity.certificatePem))
      ..usePrivateKeyBytes(utf8.encode(identity.privateKeyPem));

    try {
      _socket = await SecureSocket.connect(
        ip,
        port,
        context: context,
        // The TV's certificate is self-signed; there is nothing to validate
        // it against, and the user picked this address.
        onBadCertificate: (_) => true,
        timeout: timeout,
      );
    } on HandshakeException catch (e) {
      // On the command port this means the TV no longer trusts our
      // certificate — the pairing really is gone. On the pairing port it
      // means our certificate itself was unacceptable, which is a bug on
      // our side, not a lost pairing.
      final onCommandChannel = port == commandPort;
      throw AtvException(
        onCommandChannel
            ? 'The TV no longer recognises this remote. It was probably removed '
                'on the TV under Settings > Remotes & Accessories. (${e.message})'
            : 'The TV refused the secure connection on port $port. (${e.message})',
        kind: onCommandChannel ? AtvFailure.rejected : AtvFailure.protocol,
      );
    } on SocketException catch (e) {
      throw AtvException(
        'Can\'t reach the TV at $ip:$port. Check it is on and on the same Wi-Fi. (${e.message})',
        kind: AtvFailure.unreachable,
      );
    }

    serverMac = macFromSubject(_socket!.peerCertificate?.subject);

    _subscription = _socket!.listen(
      (chunk) {
        _reader.add(chunk);
        for (final frame in _reader.drain()) {
          _onFrame(frame);
        }
      },
      onError: (Object e) => _failAwaiting('The connection to the TV failed: $e'),
      onDone: () => _failAwaiting('The TV closed the connection.'),
      cancelOnError: true,
    );
  }

  void _onFrame(Uint8List frame) {
    final fields = parseFields(frame);

    // Ping (field 8) must be answered with a pong (field 9) or the TV hangs up.
    if (fields.containsKey(8)) {
      _send(Pb.bytesField(9, Pb.varintField(1, 25)));
      return;
    }

    final waiting = _awaiting;
    if (waiting != null && !waiting.isCompleted) {
      _awaiting = null;
      waiting.complete(frame);
    }
  }

  void _failAwaiting(String message) {
    final waiting = _awaiting;
    _awaiting = null;
    if (waiting != null && !waiting.isCompleted) {
      waiting.completeError(AtvException(message));
    }
  }

  void _send(Uint8List payload) {
    final socket = _socket;
    if (socket == null) return;
    socket.add(Pb.frame(payload));
  }

  Future<Uint8List> _receive(Duration timeout, String what) {
    final completer = Completer<Uint8List>();
    _awaiting = completer;
    return completer.future.timeout(
      timeout,
      onTimeout: () {
        _awaiting = null;
        throw AtvException('The TV did not send $what.');
      },
    );
  }

  /// Sends a pairing message and checks the status that comes back.
  Future<void> _exchange(Uint8List payload, String step) async {
    _send(payload);
    final reply = parseFields(await _receive(const Duration(seconds: 20), 'a reply to the $step'));
    final status = reply[2];
    if (status != 200) {
      throw AtvException(_statusMessage(status, step));
    }
  }

  static String _statusMessage(Object? status, String step) {
    switch (status) {
      case 402:
        return 'The TV rejected the code. Start pairing again and retype it.';
      case 401:
        return 'The TV rejected the pairing settings.';
      case 400:
        return 'The TV reported an error during $step.';
      default:
        return 'The TV refused the $step (status $status).';
    }
  }

  Future<void> disconnect() async {
    await _subscription?.cancel();
    _subscription = null;
    final socket = _socket;
    _socket = null;
    try {
      await socket?.close();
    } catch (_) {
      // already gone
    }
  }
}

/// Why a connection failed. The difference matters: the saved pairing must
/// only ever be thrown away when the TV has actually rejected it. Deleting it
/// because the TV was asleep means the user pairs again every single time.
enum AtvFailure {
  /// The TV didn't answer — off, asleep, or on another network.
  unreachable,

  /// The TV answered and refused this certificate. The pairing is gone.
  rejected,

  /// Something else: a malformed reply, a timeout mid-handshake, a wrong code.
  protocol,
}

class AtvException implements Exception {
  final String message;
  final AtvFailure kind;
  const AtvException(this.message, {this.kind = AtvFailure.protocol});
  @override
  String toString() => message;
}

/// Maps the Samsung-style key names the UI already uses onto Android
/// KeyEvent constants, so every existing button works unchanged.
class AndroidKeys {
  static const _map = <String, int>{
    'KEY_POWER': 26,
    'KEY_UP': 19,
    'KEY_DOWN': 20,
    'KEY_LEFT': 21,
    'KEY_RIGHT': 22,
    'KEY_ENTER': 23, // DPAD_CENTER
    'KEY_RETURN': 4, // BACK
    'KEY_HOME': 3,
    // The gear button. KEYCODE_MENU (82) is what Samsung wants, but on
    // Google TV it does nothing at all — the launcher listens for
    // KEYCODE_SETTINGS instead.
    'KEY_MENU': 176, // SETTINGS
    'KEY_GUIDE': 172,
    'KEY_INFO': 165,
    'KEY_EXIT': 4,
    'KEY_SOURCE': 178, // TV_INPUT
    'KEY_VOLUP': 24,
    'KEY_VOLDOWN': 25,
    'KEY_MUTE': 164,
    'KEY_CHUP': 166,
    'KEY_CHDOWN': 167,
    'KEY_PLAY': 126,
    'KEY_PAUSE': 127,
    'KEY_PLAY_PAUSE': 85,
    'KEY_STOP': 86,
    'KEY_REWIND': 89,
    'KEY_FF': 90,
    'KEY_0': 7,
    'KEY_1': 8,
    'KEY_2': 9,
    'KEY_3': 10,
    'KEY_4': 11,
    'KEY_5': 12,
    'KEY_6': 13,
    'KEY_7': 14,
    'KEY_8': 15,
    'KEY_9': 16,
  };

  /// Returns null for a key this platform has no equivalent for, so the
  /// caller can tell the user rather than silently doing nothing.
  static int? codeFor(String samsungKey) => _map[samsungKey];

  // Android KeyEvent puts the letters at 29-54 and the digits at 7-16.
  static const _punctuation = <String, int>{
    ' ': 62, // SPACE
    '.': 56, // PERIOD
    ',': 55, // COMMA
    '-': 69, // MINUS
    '@': 77, // AT
    '/': 76, // SLASH
    '+': 81, // PLUS
    '=': 70, // EQUALS
    "'": 75, // APOSTROPHE
  };

  /// The key event that types one character, or null if we can't.
  static int? codeForCharacter(String char) {
    if (char.isEmpty) return null;
    final c = char.toLowerCase().codeUnitAt(0);
    if (c >= 0x61 && c <= 0x7A) return 29 + (c - 0x61); // a-z
    if (c >= 0x30 && c <= 0x39) return 7 + (c - 0x30); // 0-9
    return _punctuation[char.toLowerCase()];
  }
}

/// Maps the Tizen app IDs the UI already carries onto Google TV deep links,
/// so the same app row works on both kinds of TV.
class AndroidAppLinks {
  static const _byTizenId = <String, String>{
    '3201907018807': 'https://www.netflix.com/title', // Netflix
    '111299001912': 'https://www.youtube.com', // YouTube
    '3201512006785': 'https://app.primevideo.com', // Prime Video
    '3201901017640': 'https://www.disneyplus.com', // Disney+
    '3201606009684': 'spotify://', // Spotify
  };

  static String? linkFor(String tizenAppId) => _byTizenId[tizenAppId];
}
