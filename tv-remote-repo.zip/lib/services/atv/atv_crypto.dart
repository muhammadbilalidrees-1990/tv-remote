import 'dart:convert';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:basic_utils/basic_utils.dart';
import 'package:crypto/crypto.dart';
import 'package:pointycastle/export.dart' show RSAPrivateKey, RSAPublicKey;

/// The client's identity for one TV: a self-signed certificate plus its key.
/// Pairing is what makes the TV trust this certificate, so these two strings
/// ARE the pairing. Lose them and the TV asks for a new code.
class ClientIdentity {
  final String certificatePem;
  final String privateKeyPem;

  const ClientIdentity({required this.certificatePem, required this.privateKeyPem});

  Map<String, dynamic> toJson() => {'cert': certificatePem, 'key': privateKeyPem};

  factory ClientIdentity.fromJson(Map<String, dynamic> j) => ClientIdentity(
        certificatePem: j['cert'] as String,
        privateKeyPem: j['key'] as String,
      );
}

/// An RSA public key reduced to the two numbers the pairing hash needs.
class RsaNumbers {
  final Uint8List modulus;
  final Uint8List exponent;
  const RsaNumbers(this.modulus, this.exponent);
}

class AtvCrypto {
  /// Generates the client certificate. RSA-2048 keygen in pure Dart takes
  /// several seconds, so it runs on its own isolate to keep the UI alive.
  static Future<ClientIdentity> generateIdentity() =>
      Isolate.run(_generateIdentitySync);

  static ClientIdentity _generateIdentitySync() {
    final pair = CryptoUtils.generateRSAKeyPair(keySize: 2048);
    final private = pair.privateKey as RSAPrivateKey;
    final public = pair.publicKey as RSAPublicKey;

    const dn = {
      'CN': 'atvremote',
      'OU': 'atvremote',
      'O': 'atvremote',
      'C': 'PK',
    };

    final csr = X509Utils.generateRsaCsrPem(dn, private, public);

    // Client Authentication matters: some TLS stacks refuse to offer a
    // certificate that isn't marked for it, and the handshake then fails
    // with no useful error.
    final cert = X509Utils.generateSelfSignedCertificate(
      private,
      csr,
      3650,
      extKeyUsage: [ExtendedKeyUsage.CLIENT_AUTH],
      keyUsage: [KeyUsage.DIGITAL_SIGNATURE, KeyUsage.KEY_ENCIPHERMENT],
    );

    return ClientIdentity(
      certificatePem: cert,
      privateKeyPem: CryptoUtils.encodeRSAPrivateKeyToPem(private),
    );
  }

  /// The pairing secret.
  ///
  /// SHA-256 over the client's modulus and exponent, then the TV's modulus
  /// and exponent, then the last four characters of the on-screen code as two
  /// bytes. The first two characters of the code are a checksum over the
  /// result — [verifyChecksum] uses them to catch a wrong answer before it
  /// gets sent.
  static Uint8List pairingSecret({
    required RsaNumbers client,
    required RsaNumbers server,
    required String code,
  }) {
    final tail = Uint8List.fromList([
      int.parse(code.substring(2, 4), radix: 16),
      int.parse(code.substring(4, 6), radix: 16),
    ]);

    final blob = <int>[
      ...client.modulus,
      ...client.exponent,
      ...server.modulus,
      ...server.exponent,
      ...tail,
    ];

    return Uint8List.fromList(sha256.convert(blob).bytes);
  }

  static bool verifyChecksum(Uint8List secret, String code) =>
      secret.isNotEmpty && secret[0] == int.parse(code.substring(0, 2), radix: 16);

  /// Pulls the RSA modulus and exponent out of a PEM certificate.
  static RsaNumbers numbersFromPem(String pem) {
    final body = pem
        .replaceAll(RegExp(r'-----(BEGIN|END) CERTIFICATE-----'), '')
        .replaceAll(RegExp(r'\s'), '');
    return numbersFromDer(base64Decode(body));
  }

  /// Pulls the RSA modulus and exponent out of a DER certificate.
  ///
  /// Walked by hand rather than with an ASN.1 library: the path is fixed and
  /// short, and this avoids depending on parser APIs that shift between
  /// package versions.
  static RsaNumbers numbersFromDer(Uint8List der) {
    final certificate = _children(_content(der, 0));
    if (certificate.isEmpty) throw const FormatException('Not a certificate');

    // certificate[0] is tbsCertificate.
    final tbs = _children(certificate[0].content);

    // tbsCertificate: [0] version (optional, context tag A0), serialNumber,
    // signature, issuer, validity, subject, subjectPublicKeyInfo.
    final hasVersion = tbs.isNotEmpty && tbs[0].tag == 0xA0;
    final spkiIndex = hasVersion ? 6 : 5;
    if (tbs.length <= spkiIndex) {
      throw const FormatException('Certificate has no public key');
    }

    // SubjectPublicKeyInfo: AlgorithmIdentifier, then a BIT STRING.
    final spki = _children(tbs[spkiIndex].content);
    if (spki.length < 2) throw const FormatException('Malformed public key');

    // A BIT STRING's first content byte counts unused trailing bits; for a
    // key it is always zero.
    final bitString = spki[1].content;
    final keyDer = Uint8List.sublistView(bitString, 1);

    // RSAPublicKey: SEQUENCE { INTEGER modulus, INTEGER exponent }
    final key = _children(_content(keyDer, 0));
    if (key.length < 2) throw const FormatException('Malformed RSA key');

    return RsaNumbers(_stripLeadingZeros(key[0].content), _stripLeadingZeros(key[1].content));
  }

  // ---- minimal DER reader ----

  static Uint8List _stripLeadingZeros(Uint8List v) {
    var i = 0;
    while (i < v.length - 1 && v[i] == 0) {
      i++;
    }
    return Uint8List.sublistView(v, i);
  }

  /// Content of the TLV starting at [offset].
  static Uint8List _content(Uint8List data, int offset) {
    final tlv = _readTlv(data, offset);
    return tlv.content;
  }

  /// Every TLV inside a constructed value's content.
  static List<_Tlv> _children(Uint8List content) {
    final out = <_Tlv>[];
    var offset = 0;
    while (offset < content.length) {
      final tlv = _readTlv(content, offset);
      out.add(tlv);
      offset = tlv.end;
    }
    return out;
  }

  static _Tlv _readTlv(Uint8List data, int offset) {
    if (offset >= data.length) throw const FormatException('Truncated DER');
    final tag = data[offset];
    var i = offset + 1;

    if (i >= data.length) throw const FormatException('Truncated DER');
    var length = data[i];
    i++;

    if (length & 0x80 != 0) {
      final byteCount = length & 0x7F;
      if (byteCount == 0 || byteCount > 4) {
        throw const FormatException('Unsupported DER length');
      }
      length = 0;
      for (var k = 0; k < byteCount; k++) {
        if (i >= data.length) throw const FormatException('Truncated DER');
        length = (length << 8) | data[i];
        i++;
      }
    }

    if (i + length > data.length) throw const FormatException('Truncated DER');
    return _Tlv(tag, Uint8List.sublistView(data, i, i + length), i + length);
  }
}

class _Tlv {
  final int tag;
  final Uint8List content;
  final int end;
  const _Tlv(this.tag, this.content, this.end);
}
