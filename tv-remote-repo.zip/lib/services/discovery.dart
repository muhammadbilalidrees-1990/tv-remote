import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;

import '../models/tv_device.dart';

/// Finds Samsung TVs on the same Wi-Fi.
///
/// 1. SSDP (fast). On iOS this needs Apple's multicast entitlement,
///    so it may silently return nothing there.
/// 2. Fallback: scan the phone's /24 subnet for port 8001 (works on iOS
///    with only the Local Network permission).
class TvDiscovery {
  static const _ssdpAddress = '239.255.255.250';
  static const _ssdpPort = 1900;
  static const _samsungSt = 'urn:samsung.com:device:RemoteControlReceiver:1';

  static Future<List<TvDevice>> discover() async {
    final found = <String, TvDevice>{};

    final ssdpIps = await _ssdp(const Duration(seconds: 3));
    final probed = await Future.wait(ssdpIps.map((ip) => probe(ip)));
    for (final d in probed.whereType<TvDevice>()) {
      found[d.ip] = d;
    }

    if (found.isEmpty) {
      for (final d in await _scanSubnet()) {
        found[d.ip] = d;
      }
    }
    return found.values.toList();
  }

  /// Checks one IP. Returns a device if it's a Samsung Tizen TV.
  static Future<TvDevice?> probe(
    String ip, {
    Duration timeout = const Duration(seconds: 3),
  }) async {
    try {
      final res = await http
          .get(Uri.parse('http://$ip:8001/api/v2/'))
          .timeout(timeout);
      if (res.statusCode != 200) return null;
      final json = jsonDecode(res.body);
      if (json is! Map<String, dynamic>) return null;
      final type = (json['type'] ?? '').toString();
      if (json['device'] == null && !type.contains('Samsung')) return null;
      return TvDevice.fromInfo(ip, json);
    } catch (_) {
      return null;
    }
  }

  static Future<Set<String>> _ssdp(Duration timeout) async {
    final ips = <String>{};
    RawDatagramSocket? socket;
    try {
      final s = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      socket = s;
      final msg = 'M-SEARCH * HTTP/1.1\r\n'
          'HOST: $_ssdpAddress:$_ssdpPort\r\n'
          'MAN: "ssdp:discover"\r\n'
          'MX: 2\r\n'
          'ST: $_samsungSt\r\n\r\n';
      final data = utf8.encode(msg);

      final sub = s.listen((event) {
        if (event != RawSocketEvent.read) return;
        final dg = s.receive();
        if (dg != null) ips.add(dg.address.address);
      });

      // UDP is unreliable, send twice.
      for (var i = 0; i < 2; i++) {
        s.send(data, InternetAddress(_ssdpAddress), _ssdpPort);
        await Future.delayed(const Duration(milliseconds: 250));
      }
      await Future.delayed(timeout);
      await sub.cancel();
    } catch (_) {
      // Blocked (e.g. iOS without multicast entitlement). Fallback handles it.
    } finally {
      socket?.close();
    }
    return ips;
  }

  static Future<List<TvDevice>> _scanSubnet() async {
    final prefixes = await _localPrefixes();
    final results = <TvDevice>[];
    const batch = 40;

    for (final prefix in prefixes) {
      for (var start = 1; start < 255; start += batch) {
        final end = min(start + batch, 255);
        final checks = [
          for (var i = start; i < end; i++) _checkHost('$prefix.$i'),
        ];
        results.addAll((await Future.wait(checks)).whereType<TvDevice>());
      }
    }
    return results;
  }

  static Future<TvDevice?> _checkHost(String ip) async {
    // Quick TCP check first; Socket.connect's timeout actually cancels.
    try {
      final s = await Socket.connect(ip, 8001,
          timeout: const Duration(milliseconds: 700));
      s.destroy();
    } catch (_) {
      return null;
    }
    return probe(ip);
  }

  /// "192.168.1" style prefixes for the phone's Wi-Fi network.
  static Future<Set<String>> _localPrefixes() async {
    final wifi = <String>{};
    final other = <String>{};
    try {
      final ifaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      );
      for (final iface in ifaces) {
        final n = iface.name.toLowerCase();
        final isWifi = n.startsWith('wlan') || n == 'en0' || n.startsWith('eth');
        for (final addr in iface.addresses) {
          final ip = addr.address;
          if (!_isPrivate(ip)) continue;
          final p = ip.split('.');
          final prefix = '${p[0]}.${p[1]}.${p[2]}';
          (isWifi ? wifi : other).add(prefix);
        }
      }
    } catch (_) {}
    return wifi.isNotEmpty ? wifi : other;
  }

  static bool _isPrivate(String ip) {
    final p = ip.split('.').map(int.tryParse).toList();
    if (p.length != 4 || p.contains(null)) return false;
    if (p[0] == 10) return true;
    if (p[0] == 192 && p[1] == 168) return true;
    if (p[0] == 172 && p[1]! >= 16 && p[1]! <= 31) return true;
    return false;
  }
}
